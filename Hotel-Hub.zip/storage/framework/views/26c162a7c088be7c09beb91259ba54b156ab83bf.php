<footer id="footer" class="h-1/4 bg-white flex items-center justify-around p-2 lg:p-8 drop-shadow-xl" dir="rtl">
    <div class="">
        <a href="/">
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.application-logo-home','data' => ['class' => 'w-24 h-24 fill-current text-gray-500']]); ?>
<?php $component->withName('application-logo-home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-24 h-24 fill-current text-gray-500']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        </a>
    </div>

    <div class="hidden lg:flex gap-8">
        <a href='#start' class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
            أعلى الصفحة
        </a>
        <a href='#main' class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
            أفضل الأطباق
        </a>
        <a href='#main' class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
            الأصناف
        </a>
    </div>

    <div class="flex flex-col items-center justify-evenly" dir="rtl">
        <h1 class="text-yellow-600 text-2xl mb-2">تواصل معنا</h1>
        <div dir="ltr" class="flex flex-col items-end">
            <p>+963 999 999 999&nbsp;&nbsp;<i class="fa fa-phone" aria-hidden="true"></i></p>
            <p>restaurant@rest.com&nbsp;&nbsp;<i class="fa fa-envelope" aria-hidden="true"></i></p>
        </div>
        <div class="flex gap-6 lg:gap-2">
            <a href=""><i class="fa fa-facebook-official text-3xl lg:text-2xl" aria-hidden="true"></i></a>
            <a href=""><i class="fa fa-instagram text-3xl lg:text-2xl" aria-hidden="true"></i></a>
            <a href=""><i class="fa fa-twitter-square text-3xl lg:text-2xl" aria-hidden="true"></i></a>
        </div>
    </div>
</footer><?php /**PATH C:\Users\Ammar Jlies\Desktop\Graduation Project\Restaurant\resources\views/layouts/footer.blade.php ENDPATH**/ ?>