<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    <title>Oops</title>
</head>
<body class="h-screen">
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="h-3/6 flex flex-col justify-center items-center space-y-4" dir="rtl">
        <h1 class="text-[125px] font-bold text-yellow-600">403</h1>
        <h1 class="text-right text-4xl font-bold text-yellow-600">عذراً... أنت لا تملك الصلاحيات الكافية للوصول لهذه الصفحة</h1>
        <h1 class="text-right text-2xl font-semibold">يبدو أن الصفحة التي تبحث عنها تمت إزالتها في وقت ما، يمكنك الرجوع إلى الصفحة الرئيسية عن طريق النقر على أيقونة الساندويتش.</h1>
    </div>

</body>
</html><?php /**PATH C:\Users\ali\Desktop\New folder (2)\Restaurant\resources\views/errors/403.blade.php ENDPATH**/ ?>