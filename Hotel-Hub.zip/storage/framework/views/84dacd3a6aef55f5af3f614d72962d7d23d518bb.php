
    <h1>Book Room <?php echo e($room->title); ?></h1>
    <hr>
    <form method="POST" action="<?php echo e(route('bookings.store')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="room_id" value="<?php echo e($room->id); ?>">
        <div class="form-group">
            <label for="booking_start_time">Booking Start Time</label>
            <input type="datetime-local" class="form-control" id="booking_start_time" name="booking_start_time" required>
        </div>
        <div class="form-group">
            <label for="booking_end_time">Booking End Time</label>
            <input type="datetime-local" class="form-control" id="booking_end_time" name="booking_end_time" required>
        </div>
        <div class="form-group">
            <label for="description">Booking Description</label>
            <textarea class="form-control" id="description" name="description" rows="3" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Book Now</button>
    </form>

<?php /**PATH C:\Users\ali\Desktop\Laravel\Restaurant\resources\views/bookings/create.blade.php ENDPATH**/ ?>