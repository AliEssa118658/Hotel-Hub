
    <h1><?php echo e($hotel->cities->title); ?> Hotels</h1>
    <hr>

        <div class="card mb-3">
            <div class="card-header">
                <?php echo e($hotel->title); ?>

            </div>
            <div class="card-body">
                <h5 class="card-title"><?php echo e($hotel->stars); ?> Stars</h5>
                <p class="card-text"><?php echo e($hotel->description); ?></p>

            </div>
        </div>




<?php /**PATH C:\Users\ali\Desktop\Laravel\Restaurant\resources\views/hotles.blade.php ENDPATH**/ ?>