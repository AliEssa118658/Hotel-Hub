<?php $__env->startSection('content'); ?>



<section class="home-banner hero-banner"  style="height:60vh">
    <!-- Slider main container -->
    <div class="swiper swiper1" style="height: 100%">

        <!-- Additional required wrapper -->
        <div class="swiper-wrapper">
            <!-- Slides -->

            <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="swiper-slide js-fullheight" style="">
                <div class="slide-img" style="background-image: url(/storage/screens/<?php echo e($offer->image); ?>); background-position: center;">
                        <div class="container h-full">
                            <div class="row h-full">
                                <div class="col-text col-md-6 h-full">
                                    <div class="banner-text-animate">
                                        <h2 class="title-b blue-text"><?php echo e($offer->description); ?></h2>
                                        <a href="<?php echo e($offer->url); ?>" class="d-flex mt-3" target="_blank">
                                            <h2 class="apply-font y-text"><?php echo e(__('Know more')); ?></h2>
                                            <img class="arrow-icon" src="/img/svg/right-y-arrow.svg" alt="Card image cap" />
                                        </a>
                                        <span class='w-text title-s terms-camp'>*Terms and conditions apply</span>
                                    </div>


                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

        <!-- If we need pagination -->
        <div class="home-banner-nav">
            <div class="swiper-pagination nav-progressbar"></div>
        </div>

    </div>
</section>



<section class="mb-5" id="besthotels">
    <div class="overflow-sec">
        <div class="row mb-5 pt-5 justify-content-center">
            <div class="col-md-7 text-center">
                <h1 class="lg-t blue-text" data-aos="fade-up" data-aos-delay="200" data-aos-duration="500"><?php echo e(__('BEST Hotels In SYRIA')); ?></h1>
            </div>
        </div>
        <div class="mb-5 mx-4 justify-content-center" data-aos="fade-up" data-aos-delay="200" data-aos-duration="500">
            <div class="   ">
                <div class="swiper swipper2">



                    <ul class="swiper-wrapper">
                        <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($hotel->stars >= 4): ?>
                        <li class="swiper-slide">
                            <a href="<?php echo e(route('hotels', $hotel->id)); ?>">
                                <!-- Card -->
                                <div class="card card-sec border-sh hover-card">
                                    <img src="/storage/screens/<?php echo e($hotel->logo); ?>" class="card-img-top card2" alt="" />

                                    <div class="card-body">
                                        <div class="card2-icon">

                                            <span class="t-card w-text"><?php echo e($hotel->average_price); ?>$ </span>
                                        </div>
                                        <div class="des-card">
                                            <h1 class="t-card b-text"><?php echo e($hotel->title); ?></h1>
                                            <div class="border-yellow py-2"></div>
                                            <img class=" icon-overview" style="width:7%; margin-bottom: 2%;" src="/img/svg/city-solid.svg" alt="Card image cap">
                                            <span class="t-des b-text"><?php echo e($hotel->cities->title); ?></span>
                                            <br>
                                            <img class=" icon-overview" style="width:7%; margin-bottom: 2%;" src="/img/svg/landmark-solid.svg" alt="Card image cap">
                                            <span class="t-des b-text"><?php echo e($hotel->region); ?></span>
                                            <br>

                                            <h3 class="t-card b-text mt-3 text-center">

                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                            <?php if($i <= round($hotel->stars)): ?>
                                            <span>    <img class="card-icon" src="/img/svg/star.svg" alt="stars" /></span>
                                            <?php else: ?>
                                              <span></span>
                                            <?php endif; ?>
                                               <?php endfor; ?>
                                              </h3>

                                        </div>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                    <!-- If we need navigation buttons -->
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-button-next"></div>
                </div>
            </div>
        </div>
    </div>
    <!-- ....... -->

    <!-- ...... -->
</section>

<section class="mb-5" id="besthotels">
    <div class="overflow-sec">
        <div class="row mb-5 pt-5 justify-content-center">
            <div class="col-md-7 text-center">
                <h1 class="lg-t blue-text" data-aos="fade-up" data-aos-delay="200" data-aos-duration="500"><?php echo e(__('Cheapest hotels in SYRIA')); ?></h1>
            </div>
        </div>
        <div class="mb-5 mx-4 justify-content-center" data-aos="fade-up" data-aos-delay="200" data-aos-duration="500">
            <div class="   ">
                <div class="swiper swipper2">



                    <ul class="swiper-wrapper">
                        <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($hotel->stars <= 2): ?>
                        <li class="swiper-slide">
                            <a href="<?php echo e(route('hotels', $hotel->id)); ?>">
                                <!-- Card -->
                                <div class="card card-sec border-sh hover-card">
                                    <img src="/storage/screens/<?php echo e($hotel->logo); ?>" class="card-img-top card2" alt="" />

                                    <div class="card-body">
                                        <div class="card2-icon">

                                            <span class="t-card w-text"><?php echo e($hotel->average_price); ?>$ </span>
                                        </div>
                                        <div class="des-card">
                                            <h1 class="t-card b-text"><?php echo e($hotel->title); ?></h1>
                                            <div class="border-yellow py-2"></div>
                                            <img class=" icon-overview" style="width:7%; margin-bottom: 2%;" src="/img/svg/city-solid.svg" alt="Card image cap">
                                            <span class="t-des b-text"><?php echo e($hotel->cities->title); ?></span>
                                            <br>
                                            <img class=" icon-overview" style="width:7%; margin-bottom: 2%;" src="/img/svg/landmark-solid.svg" alt="Card image cap">
                                            <span class="t-des b-text"><?php echo e($hotel->region); ?></span>
                                            <br>

                                            <h3 class="t-card b-text mt-3 text-center">

                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                            <?php if($i <= round($hotel->stars)): ?>
                                            <span>    <img class="card-icon" src="/img/svg/star.svg" alt="stars" /></span>
                                            <?php else: ?>
                                              <span></span>
                                            <?php endif; ?>
                                               <?php endfor; ?>
                                              </h3>

                                        </div>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </ul>
                    <!-- If we need navigation buttons -->
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-button-next"></div>
                </div>
            </div>
        </div>
    </div>
    <!-- ....... -->

    <!-- ...... -->
</section>





<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ali\Desktop\Laravel\Restaurant\resources\views/welcome.blade.php ENDPATH**/ ?>