<?php $__env->startSection('content'); ?>

<div class="container cont my-5 py-5">
    <div>
        <a href="<?php echo e(url()->previous()); ?>" class="door">
        <img class=" icon-overview-3" src="/img/svg/arrow-right-from-bracket-solid.svg" alt="Card image cap" style="width:4% ">
        </a>
    </div>
<div class="row mb-5">
    <div class="col-md-12 col -lg-12 text-center" >
        <h1 class="a-title"><?php echo e(__($booking->room->hotels->title)); ?> , <?php echo e(__($booking->room->kind)); ?><?php echo e(__(' Room')); ?></h1>
    </div>

</div>
<div class="row ">
    <div class="col-md-6 col -lg-6 text-center" >

        <img src="/img/svg/person.svg " class="icon-overview-3 person-book-icon" alt=""  style="margin-left: -10%"><span class="apply-font"> <?php echo e(Auth::user()->name); ?></span>
    </div>
    <div class="col-md-6 col -lg-6 text-center">
        <img src="/img/svg/phone-solid.svg" class="icon-overview-3" alt=""><span class="apply-font"> <?php echo e(Auth::user()->phone); ?></span>
    </div>
</div>
<div class="row ">
    <?php if(isset($booking->room)): ?>

    <div class="col-md-6 col -lg-6 text-center">
        <img class=" icon-overview-3" src="/img/svg/f-solid.svg" alt="Card image cap">
        <span class="apply-font"><?php echo e(\Carbon\Carbon::parse($booking->booking_start_time)->format('Y-m-d')); ?></span>
    </div>
    <div class="col-md-6 col -lg-6 text-center">
        <img class=" icon-overview-3" src="/img/svg/t-solid.svg" alt="Card image cap">
        <span class="apply-font"><?php echo e(\Carbon\Carbon::parse($booking->booking_end_time)->format('Y-m-d')); ?></span>
    </div>
</div>
<div class="row ">
    <div class="col-md-6 col -lg-6 text-center">


        <img class=" icon-overview-3" src="/img/svg/comment-regular.svg" alt="Card image cap" style="    margin-left: 6%;">
        <span class="apply-font"><?php echo e(__($booking->room->description)); ?></span>
    </div>

    <div class="col-md-6 col -lg-6 text-center">
        <?php if(app()->getLocale() === 'ar'): ?>


        <img class=" icon-overview-3" src="/img/svg/dollar-b.svg" alt="Card image cap" style="
        margin-left: 17%;">
        <span class="apply-font">
            <?php echo e(\Carbon\Carbon::parse($booking->booking_start_time)->diffInDays(\Carbon\Carbon::parse($booking->booking_end_time))); ?> <?php echo e(__('days')); ?> × <?php echo e($booking->room->price); ?>

            = <?php echo e($booking->room->price * \Carbon\Carbon::parse($booking->booking_start_time)->diffInDays(\Carbon\Carbon::parse($booking->booking_end_time))); ?>$</span>
        <?php else: ?>
        <img class=" icon-overview-3" src="/img/svg/dollar-b.svg" alt="Card image cap" style="
        margin-left: 17%;">
        <span class="apply-font"><?php echo e($booking->room->price); ?> x
            <?php echo e(\Carbon\Carbon::parse($booking->booking_start_time)->diffInDays(\Carbon\Carbon::parse($booking->booking_end_time))); ?> days
            = <?php echo e($booking->room->price * \Carbon\Carbon::parse($booking->booking_start_time)->diffInDays(\Carbon\Carbon::parse($booking->booking_end_time))); ?>$</span>

            <?php endif; ?>
        </div>
    </div>
    <div class="row text-center">

        <?php if($booking->paid): ?>

        <img class=" icon-overview-3" src="/img/svg/circle-check-solid.svg" alt="Card image cap" style="    width: 6%;margin: auto;">
        <?php else: ?>
        <img class=" icon-overview-3" src="/img/svg/circle-xmark-solid.svg" alt="Card image cap" style="    width: 6%;margin: auto;">
            <?php endif; ?>

        <?php else: ?>
            <p>Room not found.</p>
        <?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ali\Desktop\Laravel\Hotel-Hub\resources\views/bookings/show.blade.php ENDPATH**/ ?>