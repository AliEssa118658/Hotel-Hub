<img src="/img/svg/logo.png" alt="">
<?php /**PATH C:\Users\ali\Desktop\Laravel\Hotel-Hub\resources\views/vendor/nova/partials/logo.blade.php ENDPATH**/ ?>