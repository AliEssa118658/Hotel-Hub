
<nav class="colorlib-nav" role="navigation">


    <div class="top">
        <div class="container">
            <div class="row nav-row">
                <div class="col-md-6">
                    <ul class="sub-nav d-flex   ">
                        <li class=" "><a class=" font-xs  lw-text"
                                href=""><?php echo e(__('About Us')); ?></a></li>
                        <li class="  "><a class=" font-xs lw-text"
                                href=""><?php echo e(__('Contact Us')); ?></a></li>
                        <?php if(Auth::check()): ?>
                        <li class="  ">
                            <span class=" font-xs w-text"> <?php echo e(Auth::user()->balance); ?></span>
                            <img src="/img/svg/dollar.svg" class="icon-log" alt="masraf" />

                        </li>
                        <?php endif; ?>
                    </ul>
                </div>
                <?php if(Auth::check()): ?>
                <div class="col-md-6 text-end log-d ">
                    <div class="dropdown-login">
                        <div class="dropbtn-login">
                            <img src="/img/svg/person.svg " class="icon-log" alt="masraf" />
                            <span class="black-text blue-text bold">   <?php echo e(Auth::user()->name); ?></span>
                            <img src="/img/svg/dropdown.svg " class="icon-log" alt="masraf" />
                        </div>
                        <div class="dropdown-content">
                            <a href="#" class="font-xs blue-text">
                                <img src="/img/svg/dollar-b.svg" class="icon-log" alt="masraf" />
                                <span class="font-xs blue-text bold">      <?php echo e(Auth::user()->balance); ?></span>
                            </a>
                            <?php if(Auth::user()->role==1): ?>
                            <a href="/nova/dashboards/main" class="font-xs blue-text bold"
                                target="_blank">
                                <img src="/img/svg/setting.svg" class="icon-log" alt="masraf" /><span class="font-xs blue-text"> Control Panel</span>

                            </a>
                            <?php else: ?>
                            <a href="#" class="font-xs blue-text bold"
                            target="_blank">
                            <img src="/img/svg/setting.svg" class="icon-log" alt="masraf" /><span class="font-xs blue-text"> Setting</span>

                            </a>
                            <?php endif; ?>
                            <a href="/logout" class="font-xs blue-text"
                               ><img src="/img/svg/logout.svg" class="icon-log" alt="masraf" />
                               <span class="font-xs blue-text bold"> logout</span></a>

                        </div>
                    </div>


                </div>
                <?php else: ?>
                <div class="col-md-6 text-end log-d ">
                    <div class="dropdown-login">
                        <a href="/login" class="dropbtn-login">
                            <img src="/img/svg/lock.svg " class="icon-log" alt="masraf" />
                            <span class="font-xs blue-text"><?php echo e(__('Login')); ?></span>

                        </a>

                    </div>

                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Main header -->
    <nav class="navbar navbar-expand-lg navbar-dark  ">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('welcome')); ?>"><img src="/img/svg/Logo.png " class="custom-logo"
                    alt="masraf" /></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#main_nav"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="main_nav">
                <ul class="navbar-nav ms-auto nav-headers">
                    <li class="nav-item dropdown has-megamenu">
                        <a class="nav-link dropdown-toggle font-xs b-text"  href="#"    data-bs-toggle="dropdown">
                            <?php echo e(__('Advanced Search')); ?> </a>

                    </li>
                    <!-- .................. -->
                    <li class="nav-item dropdown has-megamenu">
                        <a class="nav-link dropdown-toggle font-xs b-text " href="#" data-bs-toggle="dropdown">
                            <?php echo e(__('Provinces')); ?> </a>
                            <div class="dropdown-menu megamenu" role="menu">
                                <div class="container">
                                    <div class="row g-5">
                                        <div class="col    ">
                                            <div class="col-megamenu">
                                                <a href="#">
                                                    <h6 class="title mega-font blue-text"><?php echo e(__('Northern Syria')); ?>

                                                        <img class="arrow-icon" src="/img/svg/right-b-arrow.svg"
                                                            alt="Card image cap">
                                                    </h6>
                                                </a>
                                                <ul class="list-unstyled">
                                                    <li><a href="/cities/13/hotels"
                                                            class="mega-font-p blue-text"><?php echo e(__('Aleppo')); ?></a>
                                                    </li>
                                                    <li><a href="/cities/20/hotels"
                                                            class="mega-font-p blue-text"><?php echo e(__('Idlib')); ?></a>
                                                    </li>
                                                    <li><a href="/cities/19/hotels"
                                                            class="mega-font-p blue-text"><?php echo e(__('Hama')); ?></a>
                                                    </li>


                                                </ul>
                                            </div> <!-- col-megamenu.// -->
                                        </div><!-- end col-3 -->
                                        <div class="col     ">
                                            <div class="col-megamenu">
                                                <a href="#">
                                                    <h6 class="title mega-font blue-text"><?php echo e(__('Southern Syria')); ?>

                                                        <img class="arrow-icon" src="/img/svg/right-b-arrow.svg"
                                                            alt="Card image cap">
                                                    </h6>
                                                </a>
                                                <ul class="list-unstyled">
                                                    <li><a href="/cities/21/hotels"
                                                            class="mega-font-p blue-text"><?php echo e(__('Daraa')); ?></a>
                                                    </li>
                                                    <li><a href="/cities/22/hotels"
                                                            class="mega-font-p blue-text"><?php echo e(__('As-Suwayda')); ?></a></li>
                                                    <li><a href="/cities/24/hotels"
                                                            class="mega-font-p blue-text"><?php echo e(__('Quneitra')); ?></a>
                                                    </li>

                                                </ul>
                                            </div> <!-- col-megamenu.// -->
                                        </div><!-- end col-3 -->



                                        <div class="col     ">
                                            <div class="col-megamenu">
                                                <a href="#">
                                                    <h6 class="title mega-font blue-text">
                                                        <?php echo e(__('Eastern Syria')); ?><img class="arrow-icon"
                                                            src="/img/svg/right-b-arrow.svg" alt="Card image cap"></h6>
                                                </a>
                                                <ul class="list-unstyled">
                                                    <li><a href="/cities/17/hotels"
                                                            class="mega-font-p blue-text"><?php echo e(__('Deir ez-Zor')); ?></a>
                                                    </li>
                                                    <li><a href="/cities/23/hotels"
                                                            class="mega-font-p blue-text"><?php echo e(__('Al-Hasakah')); ?></a>
                                                    </li>
                                                    <li><a href="/cities/15/hotels"
                                                        class="mega-font-p blue-text"><?php echo e(__('Ar Raqqah')); ?></a>
                                                </li>
                                                </ul>
                                            </div> <!-- col-megamenu.// -->
                                        </div><!-- end col-3 -->
                                        <div class="col    ">
                                            <div class="col-megamenu">
                                                <a href="#">
                                                    <h6 class="title mega-font blue-text"><?php echo e(__('Western Syria')); ?> <img
                                                            class="arrow-icon" src="/img/svg/right-b-arrow.svg"
                                                            alt="Card image cap"></h6>
                                                </a>
                                                <ul class="list-unstyled">
                                                    <li><a href="/cities/11/hotels"
                                                            class="mega-font-p blue-text"><?php echo e(__('Damascus ')); ?></a>
                                                    </li>
                                                    <li><a href="/cities/25/hotels"
                                                            class="mega-font-p blue-text"><?php echo e(__('Rural Damascus')); ?></a>
                                                    </li>
                                                    <li><a href="/cities/14/hotels"
                                                            class="mega-font-p blue-text"><?php echo e(__('Homs')); ?></a>
                                                    </li>
                                                    <li><a href="/cities/16/hotels"
                                                            class="mega-font-p blue-text"><?php echo e(__('Tartus ')); ?></a>
                                                    </li>
                                                    <li><a href="/cities/12/hotels"
                                                            class="mega-font-p blue-text"><?php echo e(__('Latakia')); ?></a>
                                                    </li>

                                                </ul>
                                            </div> <!-- col-megamenu.// -->
                                        </div><!-- end col-3 -->


                                    </div><!-- end row -->
                                </div>
                            </div>
                    </li>





                    <!-- ............... -->
                    <li class="nav-item"><a href="#"class="nav-link font-xs b-text">
                            <?php echo e(__('Tourist landmarks')); ?> </a></li>


                </ul>

            </div> <!-- navbar-collapse.// -->

        </div> <!-- container-fluid.// -->
    </nav>
</nav>
<?php /**PATH C:\Users\ali\Desktop\Laravel\Restaurant\resources\views/layouts/header.blade.php ENDPATH**/ ?>