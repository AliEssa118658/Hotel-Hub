<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    <title>Restaurant</title>
</head>
<body>
    <div x-data="{ open: false }" class="h-screen overflow-y-scroll lg:snap-y snap-mandatory">

        <div x-show="open" x-transition class="fixed top-0 left-0 w-screen h-screen bg-white z-20 pt-24 pb-8" style="display: none">
            <a href="/cart" class="absolute group top-6 left-6">
                <img class="scale-100 opacity-50 group-hover:scale-125 group-hover:opacity-100 transition-all" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAACJUlEQVR4nO2Yz0sVURTHP6/iEUaJuJQg3ISQpFCJLVzZqhbiIghc2Kq/oJUREVIvonARtDF3BUaRtAlSoV1BtWkpREQ9RQzbiAbSe3HhBl8uz3Lu3LnjwHzgwJt5c77n3Llzf5wLJSUlJXuFW8A20LS2AbwFLgIVCsCGJO9ajQL2QNOxsxSMw8AzacA0BWRAGrC2wzMzwO9/9FwIWweeA8eSNqDNETLXSnvGiTcd+wEMJm3EmggM5NQDTbEPSWfFx+J8hXw44bzIRBPKVXF8SH7MSh5mbdo1w+L4jvx4L3kMJXHsFMdNYD/xOQBs2RwaQEdSgW/SiB7i0yvxv/gIvBSBS8RnTOK/8BG4KQJ3iM9diX/DR2BUBF4Tn3mJP+Ij0O2shrFZlfiJtxPYlW9dRLqIR5fE/ZmmNnkjQheIx3mJa3LwZkqErhGPCYlrcvBmXIRMnRCLpxL3chqhkyL0mXgsSdz+NEJV4Jcs56YWyJpDslU35e7BtIIf5W2cI3uGJN6nEIL3RHAxwsZuTuI9CCF43Dm5WABO291iSI4CTySO+WT7QolfD1gergCnRHvS3ms4z6WaPl0qthF/B3Rau291j7T4r2GrwEw+VbM/egR8/c+B2G57oAK8sve37O8zFJAOYF/eSRSOqi10loG6PQyuZugXnJrniXbN0y84yzsM0Kz8glNvkcj3DP2C0+pTuJ2hX3CqNpm6xyCuefiVlJSUsDf4Axp2YWimEJkBAAAAAElFTkSuQmCC">
                <span class="scale-100 opacity-50 group-hover:scale-125 transition-all group-hover:opacity-100 absolute top-[44%] left-[57%] translate-y-[-50%] translate-x-[-50%] cart">0</span>
            </a>
        
            <div @click="open = ! open" class="fixed right-8 top-8 cursor-pointer opacity-90">
                <svg fill="#000000" height="32px" width="32px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
                viewBox="0 0 460.775 460.775" xml:space="preserve">
                    <path d="M285.08,230.397L456.218,59.27c6.076-6.077,6.076-15.911,0-21.986L423.511,4.565c-2.913-2.911-6.866-4.55-10.992-4.55
                    c-4.127,0-8.08,1.639-10.993,4.55l-171.138,171.14L59.25,4.565c-2.913-2.911-6.866-4.55-10.993-4.55
                    c-4.126,0-8.08,1.639-10.992,4.55L4.558,37.284c-6.077,6.075-6.077,15.909,0,21.986l171.138,171.128L4.575,401.505
                    c-6.074,6.077-6.074,15.911,0,21.986l32.709,32.719c2.911,2.911,6.865,4.55,10.992,4.55c4.127,0,8.08-1.639,10.994-4.55
                    l171.117-171.12l171.118,171.12c2.913,2.911,6.866,4.55,10.993,4.55c4.128,0,8.081-1.639,10.992-4.55l32.709-32.719
                    c6.074-6.075,6.074-15.909,0-21.986L285.08,230.397z"/>
                </svg>
            </div>
        
            <div class="h-full w-full flex flex-col items-center justify-center space-y-8">
        
                <a href='/#end' @click="open = ! open" class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
                    من نحن ؟
                </a>
                <a href='/#main' @click="open = ! open" class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
                    أفضل الأطباق
                </a>
                <a href='/#main' @click="open = ! open" class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
                    الأصناف
                </a>
        
                <div class="flex items-center mx-auto" dir="rtl">
                    <div class="p-2 rounded-r-full rounded-l-none bg-gray-100 focus:outline-none cursor-pointer" id="search">
                        <svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 24 24" width="24px" height="24px"><path d="M 9 2 C 5.1458514 2 2 5.1458514 2 9 C 2 12.854149 5.1458514 16 9 16 C 10.747998 16 12.345009 15.348024 13.574219 14.28125 L 14 14.707031 L 14 16 L 20 22 L 22 20 L 16 14 L 14.707031 14 L 14.28125 13.574219 C 15.348024 12.345009 16 10.747998 16 9 C 16 5.1458514 12.854149 2 9 2 z M 9 4 C 11.773268 4 14 6.2267316 14 9 C 14 11.773268 11.773268 14 9 14 C 6.2267316 14 4 11.773268 4 9 C 4 6.2267316 6.2267316 4 9 4 z"/></svg>
                    </div>
                    <input id="searchbar" class="rounded-r-none rounded-l-full bg-gray-100 focus:outline-none p-2" placeholder="بحث">
                </div>
        
                <?php if(Auth::check()): ?>
                    <div class="select-none text-2xl text-yellow-600 transition my-auto text-center">
                        <div class="block py-2">
                            <?php echo e(Auth::user()->name); ?>

                        </div>
                        <div class="text-yellow-600 my-auto text-center text-2xl flex-1 py-2 balance">
                            <p>الرصيد: <?php echo e(Auth::user()->balance); ?></p>
                        </div>
                        <a href="/addresses" class="block py-2 px-6 transition-all z-30">العناوين</a>
                        <a href="/orders" class="block py-2 px-6 transition-all z-30">طلباتي</a>
                        <a href="/points" class="block py-2 px-6 transition-all z-30">النقاط</a>
                        <a href="/logout" class="block py-2 px-6 transition-all z-30">تسجيل الخروج</a>
                    </div>
                <?php else: ?>
                    <a href="/login" class="scale-100 hover:scale-110 p-2 rounded-full bg-yellow-600 text-white hover:bg-white hover:text-yellow-600 border-2 border-yellow-600 transition-all flex items-center">
                        التسجيل / تسجيل الدخول
                    </a>
                <?php endif; ?>
        
            </div>
        </div>

        <section id="start" class="snap-start snap-always relative h-screen">
            <nav class="z-10 w-full py-4 sticky top-0 h-1/6 bg-white font-semibold backdrop-filter backdrop-blur-lg bg-opacity-30">
            
                    <div class="flex px-16 lg:px-8 items-center justify-between lg:justify-between">

                        <div class="hidden lg:flex justify-evenly space-x-8">
                            <?php if(Auth::check()): ?>
                                <div class="dropdown relative flex items-center group transition cursor-pointer select-none text-2xl text-yellow-600 my-auto">
                                    <div class="">
                                        <?php echo e(Auth::user()->name); ?>

                                        <span class="block max-w-0 group-hover:max-w-full bg-yellow-600 h-0.5 transition-all"></span>
                                    </div>

                                    <svg fill="#000000" class="ml-2 mt-[2px] transition-all" height="12px" width="12px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
	                                viewBox="0 0 330 330" xml:space="preserve">
                                    <path id="XMLID_225_" d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393
	                                c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393
	                                s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"/>
                                    </svg>

                                    <div class="dropdown-menu z-30 absolute bottom-[-210px] left-[50px] bg-white text-yellow-600 text-md border rounded-md shadow-md transition-all scale-0 origin-top whitespace-nowrap" dir="rtl"> 
                                        <a href="/addresses" class="dropdown-menu-item block py-2 px-6 transition-all hover:bg-yellow-600 hover:text-white rounded-md z-30">العناوين</a>
                                        <a href="/orders" class="dropdown-menu-item block py-2 px-6 transition-all hover:bg-yellow-600 hover:text-white rounded-md z-30">طلباتي</a>
                                        <a href="/points" class="dropdown-menu-item block py-2 px-6 transition-all hover:bg-yellow-600 hover:text-white rounded-md z-30">النقاط</a>
                                        <a href="/logout" class="dropdown-menu-item block py-2 px-6 transition-all hover:bg-yellow-600 hover:text-white rounded-md z-30">تسجيل الخروج</a>
                                    </div>
                                </div>
                                <div class="text-yellow-600 my-auto text-center text-2xl flex-1 balance">
                                    <p>الرصيد: <?php echo e(Auth::user()->balance); ?></p>
                                </div>
                            <?php else: ?>
                                <a href="/login" class="scale-100 hover:scale-110 p-2 rounded-full bg-yellow-600 text-white hover:bg-white hover:text-yellow-600 border-2 border-yellow-600 transition-all flex items-center">
                                    التسجيل / تسجيل الدخول
                                </a>
                            <?php endif; ?>
        
                            <a href="/cart" class="relative group">
                                <img class="scale-100 opacity-50 group-hover:scale-125 group-hover:opacity-100 transition-all" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAACJUlEQVR4nO2Yz0sVURTHP6/iEUaJuJQg3ISQpFCJLVzZqhbiIghc2Kq/oJUREVIvonARtDF3BUaRtAlSoV1BtWkpREQ9RQzbiAbSe3HhBl8uz3Lu3LnjwHzgwJt5c77n3Llzf5wLJSUlJXuFW8A20LS2AbwFLgIVCsCGJO9ajQL2QNOxsxSMw8AzacA0BWRAGrC2wzMzwO9/9FwIWweeA8eSNqDNETLXSnvGiTcd+wEMJm3EmggM5NQDTbEPSWfFx+J8hXw44bzIRBPKVXF8SH7MSh5mbdo1w+L4jvx4L3kMJXHsFMdNYD/xOQBs2RwaQEdSgW/SiB7i0yvxv/gIvBSBS8RnTOK/8BG4KQJ3iM9diX/DR2BUBF4Tn3mJP+Ij0O2shrFZlfiJtxPYlW9dRLqIR5fE/ZmmNnkjQheIx3mJa3LwZkqErhGPCYlrcvBmXIRMnRCLpxL3chqhkyL0mXgsSdz+NEJV4Jcs56YWyJpDslU35e7BtIIf5W2cI3uGJN6nEIL3RHAxwsZuTuI9CCF43Dm5WABO291iSI4CTySO+WT7QolfD1gergCnRHvS3ms4z6WaPl0qthF/B3Rau291j7T4r2GrwEw+VbM/egR8/c+B2G57oAK8sve37O8zFJAOYF/eSRSOqi10loG6PQyuZugXnJrniXbN0y84yzsM0Kz8glNvkcj3DP2C0+pTuJ2hX3CqNpm6xyCuefiVlJSUsDf4Axp2YWimEJkBAAAAAElFTkSuQmCC">
                                <span class="scale-100 opacity-50 group-hover:scale-125 transition-all group-hover:opacity-100 absolute top-[44%] left-[57%] translate-y-[-50%] translate-x-[-50%] cart">0</span>
                            </a>
                            <div class="flex items-center" dir="rtl">
                                <div id="search" class="p-2 rounded-r-full rounded-l-none bg-gray-100 focus:outline-none cursor-pointer">
                                    <svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 24 24" width="24px" height="24px" class=""><path d="M 9 2 C 5.1458514 2 2 5.1458514 2 9 C 2 12.854149 5.1458514 16 9 16 C 10.747998 16 12.345009 15.348024 13.574219 14.28125 L 14 14.707031 L 14 16 L 20 22 L 22 20 L 16 14 L 14.707031 14 L 14.28125 13.574219 C 15.348024 12.345009 16 10.747998 16 9 C 16 5.1458514 12.854149 2 9 2 z M 9 4 C 11.773268 4 14 6.2267316 14 9 C 14 11.773268 11.773268 14 9 14 C 6.2267316 14 4 11.773268 4 9 C 4 6.2267316 6.2267316 4 9 4 z"/></svg>
                                </div>
                                <input id="searchbar" class="rounded-r-none rounded-l-full bg-gray-100 focus:outline-none p-2" placeholder="بحث">
                            </div>
                        </div>

                        

                        <div @click="open = ! open" class="relative lg:hidden scale-125">
                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAAANUlEQVR4nO3VsQkAMAwDwd9/rGiwZIIUAYs0f6DaIBAGSQUBdjn5dXg1GpOunJM0Jn4nSTw4Ff6YkoE1i0QAAAAASUVORK5CYII=">
                        </div>
                
                        <div class="hidden lg:flex space-x-10">
                            <a href='#end' class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
                                من نحن ؟
                            </a>
                            <a href='#main' class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
                                أفضل الأطباق
                            </a>
                            <a href='#main' class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
                                الأصناف
                            </a>
                        </div>

                        <div class="">
                            <a href="/">
                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.application-logo-home','data' => ['class' => 'w-24 h-24 fill-current text-gray-500']]); ?>
<?php $component->withName('application-logo-home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-24 h-24 fill-current text-gray-500']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            </a>
                        </div>
        
                    </div>
            </nav>
            
            <section id="hero" class="relative h-5/6 bg-black">
                    <video autoplay loop muted class="h-full w-full object-cover absolute opacity-70" id="myvideo">
                        <source src="<?php echo e(asset('videos/video1.mp4')); ?>" type="video/mp4" />
                    </video>
                    <div class="relative flex flex-col items-center justify-evenly h-full">
                        <h1 class="text-4xl lg:text-7xl font-bold text-center pr-0 pt-4 text-white">
                            أشهى الأطباق بأفضل الأسعار
                            <br>
                            <span class="text-yellow-600">من مطعمنا</span>
                        </h1>
                        <a href="/search?category=1%2C2%2C3%2C4%2C5%2C6%2C7%2C8" class="text-2xl font-bold p-4 rounded-full bg-yellow-600 text-white hover:bg-white hover:text-yellow-600 border-2 border-yellow-600 hover:scale-110 transition-all">
                            استعراض الوجبات
                        </a>
                    </div>
            </section>
        </section>
    
        <main id="main" class="snap-start h-screen inline-shadow">
    
            <section id="categories" class="h-1/2 p-6 pb-0 flex flex-col justify-start">
                <h1 class="h-1/4 text-4xl lg:text-6xl font-medium text-right" dir="rtl">
                    الأصناف:
                </h1>

                <div dir="rtl" class="h-3/4 mx-auto w-full grid grid-cols-2 gap-2 md:grid-cols-3 md:gap-3 lg:grid-cols-4 lg:gap-4 justify-around my-8">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="/search?category=<?php echo e($category->id); ?>" dir="rtl" class="cursor-pointer text-xl flex justify-center items-center rounded-full bg-yellow-600 text-white hover:bg-white hover:text-yellow-600 border-2 border-yellow-600 hover:scale-105 transition-all">
                            <?php echo e($category->title); ?>

                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </section>
    
            <section id="best-sellers" class="h-1/2 px-6 flex flex-col justify-start pb-2 relative">
                <h1 class="h-1/4 text-4xl lg:text-6xl font-medium text-right" dir="rtl">
                    أفضل الأطباق:
                </h1>

                <!-- Slider main container -->
                <div class="swiper h-full md:h-3/4 w-[95%]" dir="rtl">
                    <!-- Additional required wrapper -->
                    <div class="swiper-wrapper">
                        <!-- Slides -->
                        <?php $__currentLoopData = $meals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="swiper-slide p-2 pb-4 rounded bg-white border-2 shadow-lg hover:border-yellow-600 hover:shadow-2xl transition-colors cursor-pointer meal" id="<?php echo e($meal->id); ?>">
                                <div class="h-1/2 border-2">
                                    <?php if($meal->logo == ''): ?>
                                    <img src="images/no_image.png" alt="" class="h-full w-full object-cover">
                                    <?php elseif(str_contains($meal->logo, 'images/meals')): ?>
                                    <img src="<?php echo e(asset($meal->logo)); ?>" alt="" class="h-full w-full object-cover">
                                    <?php else: ?>
                                    <img src="<?php echo e(asset('storage/'.$meal->logo)); ?>" alt="" class="h-full w-full object-cover">
                                    <?php endif; ?>
                                </div>
                                <div class="h-1/2">
                                    <div class="h-4/6 p-2">
                                        <h3 class="text-xl font-bold line-clamp-1 text-yellow-600"><?php echo e($meal->title); ?></h3>
                                        <h2 class="text-md font-semibold"><span class="text-md font-bold text-yellow-600">السعر:</span> <?php echo e(round($meal->price)); ?> ل.س</h2>
                                    </div>
                                    <div class="h-2/6 px-2 flex items-center mt-1">
                                        <button class="text-white bg-yellow-600 border-2 border-yellow-600 py-2 px-3 w-full rounded-md hover:bg-white hover:text-yellow-600 transition-all z-50">إضافة إلى السلة</button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- Navigation buttons -->
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-button-next"></div>
                </div>
            </section>
    
        </main>
    
        <section id="end" class="snap-start h-screen bg-gradient-to-b from-yellow-300 to-yellow-600">
            <section id="about-us" class="h-3/4 flex flex-col justify-center items-center lg:flex-row lg:justify-evenly lg:items-center p-6 gap-6">
                <div class="h-full w-full hidden xl:flex">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d103885.18378863078!2d35.72197594710355!3d35.54352590077461!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1526ac2d61d4607d%3A0x8e325bf8a14195de!2sLatakia%2C%20Syria!5e0!3m2!1sen!2s!4v1676035766110!5m2!1sen!2s" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>
                <div class="bg-white flex flex-col h-full w-full shadow-2xl p-6 rounded space-y-4">
                    <h1 class="text-4xl font-bold text-right text-yellow-600">من نحن؟</h1>
                    <h1 class="text-3xl font-semibold text-right overflow-y-scroll md:overflow-hidden" dir="rtl" style="text-align: justify;">
                        منذ بداياتنا المتواضعة في عام 2015، تطّور مطعمنا بكثير من الجهد والشّغف في إعداد أشهى الوجبات الشّرقيّة والغربيّة.
                        <br>
                        على عكس العديد من المطاعم الأخرى، فقد قمنا بتصميم مطعمنا بشكل يميّزه دون غيره بجعل عملائنا يعيشون تجربة تذوّق فريدة ومختلفة عن بقيّة المطاعم الّتي قاموا بزيارتها.
                        <br>
                        طموحنا أن تنضمّ إلينا في هذه التّجربة المميّزة وأن تجعل منّا خياراً مستقبليّاً دائماً لك.

                    </h1>
                </div>
            </section>
        
            <footer id="footer" class="h-1/4 bg-white flex items-center justify-around p-2 lg:p-8 drop-shadow-xl" dir="rtl">
                <div class="">
                    <a href="/">
                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.application-logo-home','data' => ['class' => 'w-24 h-24 fill-current text-gray-500']]); ?>
<?php $component->withName('application-logo-home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-24 h-24 fill-current text-gray-500']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    </a>
                </div>

                <div class="hidden lg:flex gap-8">
                    <a href='#start' class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
                        أعلى الصفحة
                    </a>
                    <a href='#main' class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
                        أفضل الأطباق
                    </a>
                    <a href='#main' class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
                        الأصناف
                    </a>
                </div>

                <div class="flex flex-col items-center justify-evenly" dir="rtl">
                    <h1 class="text-yellow-600 text-2xl mb-2">تواصل معنا</h1>
                    <div dir="ltr" class="flex flex-col items-end">
                        <p>+963 999 999 999&nbsp;&nbsp;<i class="fa fa-phone" aria-hidden="true"></i></p>
                        <p>restaurant@rest.com&nbsp;&nbsp;<i class="fa fa-envelope" aria-hidden="true"></i></p>
                    </div>
                    <div class="flex gap-6 lg:gap-2">
                        <a href=""><i class="fa fa-facebook-official text-3xl lg:text-2xl" aria-hidden="true"></i></a>
                        <a href=""><i class="fa fa-instagram text-3xl lg:text-2xl" aria-hidden="true"></i></a>
                        <a href=""><i class="fa fa-twitter-square text-3xl lg:text-2xl" aria-hidden="true"></i></a>
                    </div>
                </div>
            </footer>
        </section>
    </div>

    <div class="hidden rotate-180">

    </div>

</body>
</html><?php /**PATH C:\Users\Ammar Jlies\Desktop\Graduation Project\Restaurant\resources\views/welcome.blade.php ENDPATH**/ ?>