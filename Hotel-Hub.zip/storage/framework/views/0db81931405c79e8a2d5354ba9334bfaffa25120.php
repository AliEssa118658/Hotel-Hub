<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    <title>Restaurant</title>
</head>
<body class="h-screen">
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="min-h-fit lg:h-5/6 lg:min-h-0 flex justify-center items-start lg:items-center mb-4" dir="rtl">
        <div class="p-4 pt-2 border-2 h-5/6 w-5/6 shadow-xl flex flex-col divide-y-2 bg-white rounded overflow-y-auto">
            <?php if($orders->count() > 0): ?>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="<?php echo e($order->id); ?>" class="w-full p-2 flex flex-col gap-2 lg:gap-0 order-container">
                    <div class="w-full flex flex-col lg:flex-row items-center justify-center lg:justify-between gap-2 lg:gap-0">
                        <div class="flex-1 w-full lg:w-fit">
                            <p class="text-yellow-600">رقم الطلب: <span class="text-black"><?php echo e($order->id); ?></span></p>
                            <p class="text-yellow-600">الإجمالي: <span class="text-black total"><?php echo e(round($order->total_price)); ?></span></p>
                        </div>
                        <div class="flex-1 w-full lg:w-fit">
                            <p class="text-yellow-600">حالة الطلب: <span class="text-black status"><?php echo e($order->status); ?></span></p>
                            <p class="text-yellow-600">الملاحظات: <span class="text-black"><?php echo e($order->notes); ?></span></p>
                            <p class="text-yellow-600">وقت إنشاء الطلب: <span class="text-black"><?php echo e($order->created_at->diffForHumans()); ?></span></p>
                        </div>
                    </div>
                    <div class="w-full flex flex-col lg:flex-row justify-center lg:justify-between gap-2 lg:gap-0">
                        <div class="flex-1 w-full lg:w-fit">
                            
                            <p class="text-yellow-600 font-bold">العنوان: <span class="text-black font-normal"><?php echo e($order->address()->withTrashed()->first()->title); ?> - <?php echo e($order->address()->withTrashed()->first()->region); ?> - <?php echo e($order->address()->withTrashed()->first()->street); ?> - الطابق <?php echo e($order->address()->withTrashed()->first()->floorNo); ?></span></p>
                        </div>
                        <div class="flex-1 w-full lg:w-fit">
                            <p class="text-yellow-600 font-bold">الوجبات: </p>
                            <p>
                                <?php $__currentLoopData = $order->meals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><?php echo e($meal->title); ?> × <?php echo e($meal->pivot->quantity); ?>: <?php echo e($meal->pivot->meal_price * $meal->pivot->quantity); ?> ل.س</p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>
                        </div>
                    </div>
                    <?php if($order->status == "قيد الانتظار"): ?>
                    <div class="flex flex-col items-end justify-center space-y-2 w-full">
                            <button class="w-full lg:w-32 text-center transition-all py-2 px-4 border-2 border-yellow-600 bg-yellow-600 text-white hover:bg-white hover:text-yellow-600 hover:scale-110 rounded-md cancelOrderBtn">إلغاء الطلب</button>
                    </div>
                    <?php else: ?>
                    <div class="flex flex-col items-end justify-center space-y-2 w-full">
                        <button disabled class="w-full lg:w-32 opacity-30 text-center transition-all py-2 px-4 border-2 border-yellow-600 bg-yellow-600 text-white rounded-md">إلغاء الطلب</button>
                    </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <h1 class="text-center text-yellow-600 text-2xl">لا يوجد طلبات</h1>
            <?php endif; ?>
        </div>
    </div>

</body>
</html><?php /**PATH C:\Users\ali\Desktop\New folder (2)\Restaurant\resources\views/orders.blade.php ENDPATH**/ ?>