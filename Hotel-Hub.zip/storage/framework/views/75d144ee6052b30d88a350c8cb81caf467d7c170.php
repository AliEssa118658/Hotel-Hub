<?php $__env->startSection('content'); ?>

<section class="home ">
    <h1 class="lg2-t text-center blue-text" data-aos="fade-up" data-aos-delay="200" data-aos-duration="500"><?php echo e($rooms->kind); ?> Room</h1>
</section>
<section class="home-banner hero-banner">

    <div class="swiper mySwiper" style="    width: 100%;padding-top: 25px;padding-bottom: 50px;">
        <div class="swiper-wrapper">
            <?php for($i = 1; isset($rooms->{'image'.$i}); $i++): ?>
                <div class="swiper-slide" style="background-position: center;background-size: cover;width: 60%;height: 400px;">
                    <img src='/storage/screens/<?php echo e($rooms->{'image'.$i}); ?>' style="border-radius:25px;width:100%;height:100%"/>
                </div>
             <?php endfor; ?>
        </div>
        <div class="swiper-pagination"></div>
      </div>

</section>



<section class=" my-4">
    <div class="container">
    <div class="row  home-page-text "data-aos="fade-up" data-aos-delay="200" data-aos-duration="500">

    <div class="col-md-12 border-b">


    <div class="panel    my-4 " style="display: block;"  >
        <div class="row  my-5  " data-aos="fade-up" data-aos-delay="200" data-aos-duration="500">

            <div class="col-md-6 col-lg-6 " style="text-align:left">
                <div class="row  " data-aos="fade-up" data-aos-delay="200" data-aos-duration="500">


                    <div class="col-md-6 col-lg-6">

                        <div class="d-flex">
                            <img class=" icon-overview-2" src="/img/svg/intercom.svg" alt="Card image cap">
                            <p class="t-card b-text " style="margin:auto 0%;"><?php echo e($rooms->kind); ?> Room</p>
                        </div>

                    </div>
                </div>
                <div class="row  my-3  " data-aos="fade-up" data-aos-delay="200" data-aos-duration="500">

                    <div class="col-md-6 col-lg-6 align-center">
                        <?php if($rooms->persons == 1): ?>

                        <div class="d-flex">
                            <img class=" icon-overview-2" src="/img/svg/user-solid.svg" alt="Card image cap">
                            <p class="t-card b-text " style="margin:auto 0%;"><?php echo e($rooms->persons); ?> person</p>
                        </div>
                        <?php else: ?>
                        <div class="d-flex">
                            <img class=" icon-overview-2" src="/img/svg/user-group-solid.svg" alt="Card image cap">
                            <p class="t-card b-text " style="margin:auto 0%;"><?php echo e($rooms->persons); ?> persons</p>
                        </div>
                        <?php endif; ?>
                    </div>


                </div>
                <div class="row  my-3  " data-aos="fade-up" data-aos-delay="200" data-aos-duration="500">
                    <div class="col-md-6 col-lg-6 align-center">
                        <?php if($rooms->kind =='Single'): ?>
                        <div class="d-flex">
                            <img class=" icon-overview-2" src="/img/svg/bed-solid.svg" alt="Card image cap">
                            <p class="t-card b-text " style="margin:auto 0%;">1 single Bed</p>
                        </div>
                        <?php endif; ?>
                        <?php if($rooms->kind =='Double'): ?>
                        <div class="d-flex">
                            <img class=" icon-overview-2" src="/img/svg/bed-solid.svg" alt="Card image cap">
                            <p class="t-card b-text " style="margin:auto 0%;">1 King bed</p>
                        </div>
                        <?php endif; ?>
                        <?php if($rooms->kind =='Family'): ?>
                        <div class="d-flex">
                            <img class=" icon-overview-2" src="/img/svg/bed-solid.svg" alt="Card image cap">
                            <p class="t-card b-text " style="margin:auto 0%;">1 King beds,</p>
                            <p class="t-card b-text " style="margin:auto 0%;">2 single beds</p>
                        </div>
                        <?php endif; ?>
                        <?php if($rooms->kind =='Suite'): ?>
                        <div class="d-flex">
                            <img class=" icon-overview-2" src="/img/svg/bed-solid.svg" alt="Card image cap">
                            <p class="t-card b-text " style="margin:auto 0%;">2 King beds,</p>
                            <p class="t-card b-text " style="margin:auto 0%;">2 single beds</p>
                        </div>
                        <?php endif; ?>

                    </div>

                </div>
           </div>
            <div class="col-md-6 col-lg-6 " style="text-align:left">
                <div class="d-flex">
                    <img class=" icon-overview-2" src="/img/svg/check-solid.svg" alt="Card image cap">
                    <p class="t-card b-text " style="margin:auto 0%;"><?php echo e($rooms->description); ?></p>
                </div>

            </div>
        </div>
        <div class="row  my-3  " data-aos="fade-up" data-aos-delay="200" data-aos-duration="500">
            <form method="POST" class="row" action="<?php echo e(route('bookings.store')); ?>">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="room_id" value="<?php echo e($rooms->id); ?>">
                <div class="col-md-6 col-lg-6 " style="text-align:left">
                    <div class="form-group">

                        <label class="t-card b-text" for="booking_start_time">Booking Start Time</label>
                        <input type="date" class="form-control" id="booking_start_time" name="booking_start_time" required>
                    </div>
                </div>
                <div class="col-md-6 col-lg-6 " style="text-align:left">
                    <div class="form-group">
                        <label class="t-card b-text" for="booking_end_time">Booking End Time</label>
                        <input type="date" class="form-control" id="booking_end_time" name="booking_end_time" required  min="#booking_start_time">
                    </div>
                </div>
        </div>
        <div class="row  my-3  " data-aos="fade-up" data-aos-delay="200" data-aos-duration="500">
            <div class="col-md-6 col-lg-6 " style="text-align:left">

                <div class="form-group">
                    <label class="t-card b-text" for="description">Booking Notes</label>
                    <textarea class="form-control" id="description" name="description" rows="3" style="width: 100%" placeholder="any extra notes for this booking"></textarea>
                </div>
            </div>
            <div class="col-md-6 col-lg-6 " style="text-align:left">

                <button type="submit" class="btn-book t-card y-text" >Book Now</button>
            </div>
        </div>

        </form>

    </div>



    </div>
    </div>
    </div>

</section>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />

<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    var swiper = new Swiper(".mySwiper", {
      effect: "coverflow",
      grabCursor: true,
      centeredSlides: true,
      slidesPerView: "auto",
      coverflowEffect: {
        rotate: 50,
        stretch: 0,
        depth: 100,
        modifier: 1,
        slideShadows: true,
      },
      pagination: {
        el: ".swiper-pagination",
      },
    });


  </script>
<script>
       $(document).ready(function() {
        $('#booking_start_time').change(function() {
            var startDateTime = new Date($('#booking_start_time').val());
            var minEndDateTime = new Date(startDateTime.getTime() + (60 * 60 * 1000));
            $('#booking_end_time').attr('min', minEndDateTime.toISOString().slice(0, 16));
        });
    });
</script>

<?php $__env->stopSection(); ?>










<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ali\Desktop\Laravel\Restaurant\resources\views/rooms.blade.php ENDPATH**/ ?>