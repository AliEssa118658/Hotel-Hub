<p class="mt-8 text-center text-xs text-80">
    <a href="<?php echo e(route('welcome')); ?>" class="text-primary dim no-underline">Hotel Hub</a>


</p>
<?php /**PATH C:\Users\ali\Desktop\Laravel\Hotel-Hub\resources\views/vendor/nova/partials/footer.blade.php ENDPATH**/ ?>