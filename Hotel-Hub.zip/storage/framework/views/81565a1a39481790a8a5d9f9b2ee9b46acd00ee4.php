<p><b>Name:</b> <?php echo e($name); ?></p>
<p><b>Phone:</b> <?php echo e($phone); ?></p>
<p><b>Email:</b> <?php echo e($email); ?></p>
<p><b>Location:</b> <?php echo e($location); ?></p>


<br />
<p><b>Subject:</b> <?php echo e($subject); ?></p>
<p><b>Message:</b> <?php echo e($msg); ?></p>

<p><b>How would you like us to contact you?</b> <?php echo e($howContact); ?></p>
<?php /**PATH C:\Users\ali\Desktop\Laravel\Hotel-Hub\resources\views/emails/contact.blade.php ENDPATH**/ ?>