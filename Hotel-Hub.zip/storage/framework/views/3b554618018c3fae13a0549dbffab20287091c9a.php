<?php echo e($slot); ?>

<?php /**PATH C:\Users\Ammar Jlies\Desktop\Graduation Project\Restaurant\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>