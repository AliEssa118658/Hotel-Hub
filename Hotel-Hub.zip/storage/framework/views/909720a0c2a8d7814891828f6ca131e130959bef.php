<?php $__env->startSection('content'); ?>

    <div class="container">


        <form method="GET" action="<?php echo e(route('advancedSearch')); ?>">
            <div class="row">

                <div class="col-md-3 col-lg-3 col-sm-3 my-5">
                    <div class="row mb-2">
                        <div class="form-group ">
                            <label class="t-card" for="cities"><?php echo e(__('Cities')); ?></label>
                            <div>
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div>
                                        <input type="checkbox" name="cities[]" value="<?php echo e($city->id); ?>" <?php if(in_array($city->id, Request::get('cities', []))): ?> checked <?php endif; ?>>
                                        <label><?php echo e(__($city->title)); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="border-yellow-2 my-3"></div>


                    <div class="row mb-2">
                        <div class="form-group ">
                            <label class="t-card"  for="hotel"><?php echo e(__('Hotel')); ?></label>
                            <input placeholder="<?php echo e(__('Optional')); ?>" type="text" class="form-control w-80" id="hotel" name="hotel" value="<?php echo e(Request::get('hotel')); ?>">
                        </div>
                    </div>
                    <div class="border-yellow-2 my-3"></div>
                    <div class="row mb-2">
                        <div class="form-group">
                            <label class="t-card" for="region"><?php echo e(__('Region')); ?></label>
                            <input placeholder="<?php echo e(__('Optional')); ?>" type="text" class="form-control w-80" id="region" name="region" value="<?php echo e(Request::get('region')); ?>">
                        </div>
                    </div>
                    <div class="border-yellow-2 my-3"></div>
                    <div class="row mb-2">
                        <div class="form-group">
                            <label class="t-card" for="room"><?php echo e(__('Room Kind')); ?></label>
                            <select class="form-control w-80" id="room" name="room">
                                <option value="All" <?php echo e(Request::get('room') == 'All' ? 'selected' : ''); ?>><?php echo e(__('All')); ?></option>
                                <option value="Single" <?php echo e(Request::get('room') == 'Single' ? 'selected' : ''); ?>><?php echo e(__('Single')); ?></option>
                                <option value="Double" <?php echo e(Request::get('room') == 'Double' ? 'selected' : ''); ?>><?php echo e(__('Double')); ?></option>
                                <option value="Family" <?php echo e(Request::get('room') == 'Family' ? 'selected' : ''); ?>><?php echo e(__('Family')); ?></option>
                                <option value="Suite" <?php echo e(Request::get('room') == 'Suite' ? 'selected' : ''); ?>><?php echo e(__('Suite')); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="border-yellow-2 my-3"></div>

                    <div class="row mb-2">
                        <div class="form-group">
                            <label class="t-card" for="region"><?php echo e(__('Persons')); ?></label>
                            <input placeholder="<?php echo e(__('Optional')); ?>" type="number" class="form-control w-80" id="persons" name="persons" value="<?php echo e(Request::get('persons')); ?>">
                        </div>
                    </div>
                    <div class="border-yellow-2 my-3"></div>
                    <div class="row">
                        <div class="form-group">
                            <label class="t-card" for="price"><?php echo e(__('Price')); ?></label>
                            <div class="d-flex align-items-center">
                                <span class="ml-2"  id="price-value"><?php echo e(Request::get('price')); ?>$</span>
                                <input type="range" class="form-control-range" id="price" name="price" min="0" max="1000" step="10" value="<?php echo e(Request::get('price')); ?>">
                                <span class="mr-2">1000$</span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-9 col-lg-9 col-sm-9">

                    <div class="row">
                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="start_date"><?php echo e(__('Start Date')); ?></label>
                                <input type="date" class="form-control" id="start_date" name="start_date" value="<?php echo e(Request::get('start_date')); ?>">
                            </div>
                        </div>

                        <div class="col-md-5">
                            <div class="form-group">
                                <label for="end_date"><?php echo e(__('End Date')); ?></label>
                                <input type="date" class="form-control" id="end_date" name="end_date" value="<?php echo e(Request::get('end_date')); ?>">
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('Search')); ?></button>


                            </div>
                        </div>
                    </div>
                    <?php if($rooms->count() > 0): ?>
                        <div class="row my-5 px-4">
                            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row my-4 card-room ">
                                    <div class="col-md-7  pt-4 pb-2">
                                            <h3 class="card-title y-text"><?php echo e(__($room->hotels->title)); ?></h3>
                                            <div class="d-flex mb-2">
                                                <img class=" icon-overview-4" src="/img/svg/city-solid.svg" alt="Card image cap">
                                                <p class="t-card b-text " style="margin:auto 0%;">  <?php echo e(__($room->hotels->cities->title)); ?></p>
                                            </div>
                                            <div class="d-flex mb-2">
                                                <img class=" icon-overview-4" src="/img/svg/landmark-solid.svg" alt="Card image cap">
                                                <p class="t-card b-text " style="margin:auto 0%;">  <?php echo e(__($room->hotels->region)); ?></p>
                                            </div>
                                            <div class="d-flex mb-2">
                                                <img class=" icon-overview-4" src="/img/svg/street-view-solid.svg" alt="Card image cap">
                                                <p class="t-card b-text " style="margin:auto 0%;">  <?php echo e(__($room->hotels->street)); ?></p>
                                            </div>
                                            <div class="d-flex mb-2">
                                                <img class=" icon-overview-4" src="/img/svg/intercom.svg" alt="Card image cap">
                                                <p class="t-card b-text " style="margin:auto 0%;"> <?php echo e(__($room->kind)); ?> </p>
                                            </div>

                                            <?php if($room->persons <= 1): ?>

                                            <div class="d-flex mb-2">
                                                <img class=" icon-overview-4" src="/img/svg/user-solid.svg" alt="Card image cap">
                                                <p class="t-card b-text " style="margin:auto 0%;"><?php echo e($room->persons); ?> <?php echo e(__('person')); ?></p>
                                            </div>
                                            <?php else: ?>
                                            <div class="d-flex mb-2">
                                                <img class=" icon-overview-4" src="/img/svg/user-group-solid.svg" alt="Card image cap">
                                                <p class="t-card b-text " style="margin:auto 0%;"><?php echo e($room->persons); ?><?php echo e(__('persons')); ?></p>
                                            </div>
                                            <?php endif; ?>
                                            <?php if($room->kind =='Single'): ?>
                                            <div class="d-flex mb-2">
                                                <img class=" icon-overview-4" src="/img/svg/bed-solid.svg" alt="Card image cap">
                                                <p class="t-card b-text " style="margin:auto 0%;"><?php echo e(__('1 single Bed')); ?></p>
                                            </div>
                                            <?php endif; ?>
                                            <?php if($room->kind =='Double'): ?>
                                            <div class="d-flex mb-2">
                                                <img class=" icon-overview-4" src="/img/svg/bed-solid.svg" alt="Card image cap">
                                                <p class="t-card b-text " style="margin:auto 0%;"><?php echo e(__('1 King bed')); ?></p>
                                            </div>
                                            <?php endif; ?>
                                            <?php if($room->kind =='Family'): ?>
                                            <div class="d-flex mb-2">
                                                <img class=" icon-overview-4" src="/img/svg/bed-solid.svg" alt="Card image cap">
                                                <p class="t-card b-text " style="margin:auto 0%;"><?php echo e(__('1 King beds')); ?>,</p>
                                                <p class="t-card b-text " style="margin:auto 0%;"><?php echo e(__('2 single beds')); ?></p>
                                            </div>
                                            <?php endif; ?>
                                            <?php if($room->kind =='Suite'): ?>
                                            <div class="d-flex mb-2">
                                                <img class=" icon-overview-4" src="/img/svg/bed-solid.svg" alt="Card image cap">
                                                <p class="t-card b-text " style="margin:auto 0%;"><?php echo e(__('2 King beds')); ?>,</p>
                                                <p class="t-card b-text " style="margin:auto 0%;"><?php echo e(__('2 single beds')); ?></p>
                                            </div>
                                            <?php endif; ?>
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                            <?php if($i <= round($room->hotels->stars)): ?>
                                            <span>    <img class="icon-overview-5" src="/img/svg/star.svg" alt="stars" /></span>
                                            <?php else: ?>
                                              <span></span>
                                            <?php endif; ?>
                                            <?php endfor; ?>
                                            <div class=" btn btn-warning btn-price" style="position: relative;left:35%">

                                                <span class="t-card w-text"> <?php echo e($room->price); ?>$</span>
                                            </div>
                                            <br>
                                            <br>
                                            <div class="btn btn-light ">

                                              <a class="t-card y-text" href="<?php echo e(route('rooms.index', ['hotel' =>  $room->hotels->id,'room' => $room->id])); ?>"><?php echo e(__('Booking')); ?></a>
                                            </div>


                                    </div>

                                    <div class=" img-search col-md-5 ">
                                            <img src="/storage/screens/<?php echo e($room->logo); ?>" alt="" class="d-block img-card">
                                    </div>

                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                    <div class="text-center" style="margin: auto">
                        <p class="a-title2 b-text my-5"><?php echo e(__(' No room found.')); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </form>

        <hr>


    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('extra'); ?>

<script>
    const priceRangeInput = document.getElementById('price');
    const priceValue = document.getElementById('price-value');

    priceRangeInput.addEventListener('input', function() {
        priceValue.textContent = priceRangeInput.value + '$';
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ali\Desktop\Laravel\Hotel-Hub\resources\views/search.blade.php ENDPATH**/ ?>