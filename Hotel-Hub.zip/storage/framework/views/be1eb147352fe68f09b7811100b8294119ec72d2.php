<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\ali\Desktop\New folder (2)\Restaurant\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>