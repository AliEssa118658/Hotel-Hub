<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    <title>Restaurant</title>
</head>
<body class="h-screen">
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="min-h-fit lg:h-5/6 lg:min-h-0 flex justify-center items-start lg:items-center mb-4" dir="rtl">
        <div class="p-4 pt-4 border-2 h-5/6 w-5/6 shadow-xl flex flex-col bg-white rounded overflow-y-auto main-container">
            <h1 class="text-center text-2xl font-bold text-yellow-600">قم باستبدال نقاطك والحصول على رصيد</h1>
            <h1 class="text-center text-2xl font-bold text-yellow-600 my-points">نقاطي: <?php echo e($userPoints); ?></h1>

            <div class="flex flex-col space-y-4 mt-8">
                <?php if($points && $points->count() > 0): ?>
                    <?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="<?php echo e($point->id); ?>" class="flex-1 w-full h-fit border-2 rounded-md flex flex-col lg:flex-row justify-center lg:justify-between items-center space-y-2 lg:space-y-0 p-6 pointDeal">
                        <h1 class="flex-[2_2_0%]"><span class="text-yellow-600">النقاط:</span> <?php echo e($point->points); ?> نقطة</h1>
                        <h1 class="flex-[2_2_0%]"><span class="text-yellow-600">الرصيد:</span> <?php echo e($point->balance); ?> ل.س</h1>
                        <button class="flex-1 w-full lg:w-32 text-center transition-all py-2 px-4 border-2 border-yellow-600 bg-yellow-600 text-white hover:bg-white hover:text-yellow-600 hover:scale-105 rounded-md replacePointsBtn">استبدال</button>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <h1 class="text-center text-2xl font-bold text-yellow-600">لا يوجد عروض لاستبدال النقاط في الوقت الحالي</h1>
                <?php endif; ?>
            </div>
        </div>
    </div>

</body>
</html><?php /**PATH C:\Users\ali\Desktop\Laravel\Restaurant\resources\views/points.blade.php ENDPATH**/ ?>