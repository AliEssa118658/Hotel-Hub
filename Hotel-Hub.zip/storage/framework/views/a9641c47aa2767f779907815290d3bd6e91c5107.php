<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    <title>Restaurant</title>
</head>
<body>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <section id="results" class="min-h-[83.333333%] flex flex-col lg:flex-row px-8 mb-4 gap-10 lg:w-full">
        <div class="flex flex-col gap-4 h-full lg:w-3/4">
            <h1 class="font-bold text-2xl" dir="rtl">النتائج:</h1>
            <?php $__currentLoopData = $meals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="border w-full lg:h-48 shadow-md flex lg:flex-row flex-col pb-4 lg:p-0 items-center justify-center space-x-0 space-y-4 lg:space-x-12 lg:space-y-0 hover:border-yellow-600 cursor-pointer meal" id="<?php echo e($meal->id); ?>" dir="rtl">
                    <div class="flex-1 h-full">
                        <?php if($meal->logo == ''): ?>
                            <img src="<?php echo e(asset("images/no_image.png")); ?>" alt="" class="h-full w-full object-cover">
                        <?php elseif(str_contains($meal->logo, 'images/meals')): ?>
                            <img src="<?php echo e(asset($meal->logo)); ?>" alt="" class="h-full w-full object-cover">
                        <?php else: ?>
                        <img src="<?php echo e(asset('storage/'.$meal->logo)); ?>" alt="" class="h-full w-full object-cover">
                        <?php endif; ?>
                    </div>
                    <div class="flex-1 flex flex-col px-2 lg:pr-8">
                        <h1 class="font-bold text-lg"><?php echo e($meal->title); ?></h1>
                        <h1 class="text-md line-clamp-2"><?php echo e($meal->description); ?></h1>
                    </div>
                    <div class="flex-1 flex flex-col justify-around items-center gap-4">
                        <h1 class=""><span class="text-yellow-600 font-semibold text-lg">السعر:</span> <?php echo e($meal->price); ?></h1>
                        <button class="bg-yellow-600 text-white hover:bg-white border-2 border-yellow-600 hover:text-yellow-600 py-2 px-4 rounded-md transition-all">إضافة إلى السلة</button>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($meals->count() == 0): ?>
            <h1 class="w-full text-xl font-bold pr-6" dir="rtl">لا يوجد نتائج</h1>
            <?php endif; ?>
        </div>
        <div class="w-full lg:w-[20%] h-fit border-l-0 border-t-2 lg:border-l-2 lg:border-t-0 space-y-4 lg:space-y-8 lg:sticky lg:top-4 lg:right-0 mt-4 lg:mt-0" dir="rtl">
            <h1 class="font-bold text-2xl" dir="rtl">الأصناف:</h1>
            <div id="categories" class="mr-4 lg:mx-auto grid grid-cols-4 lg:grid-cols-2 lg:gap-y-4 items-center justify-between">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h1 class="font-semibold"><?php echo e($category->title); ?></h1>
                <input type="checkbox" name="" id="<?php echo e($category->id); ?>" class="text-yellow-600 focus:ring-yellow-600 justify-self-end ml-4 lg:ml-10 cursor-pointer">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <button id="categorySearch" class="col-span-4 col-start-2 col-end-4 lg:col-span-2 rounded-full lg:ml-12 mt-4 lg:mt-8 px-4 py-2 bg-yellow-600 border-2 border-yellow-600 text-white hover:text-yellow-600 hover:bg-white transition-all text-center block">بحث</button>
            </div>
        </div>
    </section>

</body>
</html><?php /**PATH C:\Users\ali\Desktop\New folder (2)\Restaurant\resources\views/search.blade.php ENDPATH**/ ?>