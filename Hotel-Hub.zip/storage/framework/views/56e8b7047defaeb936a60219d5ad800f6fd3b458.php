<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    <title><?php echo e($meal->title); ?></title>
</head>

<body class="h-fit lg:h-screen">
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="min-h-fit lg:h-5/6 lg:min-h-0 flex justify-center items-start lg:items-center mb-4" dir="rtl">
        <div class="border-2 h-5/6 w-5/6 shadow-xl flex flex-col lg:flex-row divide-x-2 divide-x-reverse bg-white rounded">
            <div class="h-full w-full flex flex-col">
                <?php if($meal->logo == ''): ?>
                <img src="<?php echo e(asset("images/no_image.png")); ?>" alt="" class="h-full w-full object-cover">
                <?php elseif(str_contains($meal->logo, 'images/meals')): ?>
                <img src="<?php echo e(asset($meal->logo)); ?>" alt="" class="h-full w-full object-cover">
                <?php else: ?>
                <img src="<?php echo e(asset('storage/'.$meal->logo)); ?>" alt="" class="h-full w-full object-cover">
                <?php endif; ?>
            </div>
            <div class="h-full w-full p-4 flex flex-col gap-4">
                <div class="h-[50%] w-full overflow-y-scroll xl:overflow-hidden">
                    <h1 class="text-2xl font-bold text-yellow-600"><?php echo e($meal->title); ?></h1>
                    <h1 class="text-lg font-semibold mt-4"><?php echo e($meal->description); ?></h1>
                </div>
                <h1 class="text-lg h-[10%] w-full font-semibold mb-4"><span class="text-2xl font-bold text-yellow-600">السعر:</span> <?php echo e(round($meal->price)); ?> ل.س</h1>
                <div class="h-[40%] w-full flex flex-col items-center justify-around bg-white rounded-md p-4 gap-4">
                    <div class="flex flex-col justify-center md:flex-row md:justify-around items-center gap-6">
                        <div class="flex justify-center items-center gap-2">
                            <label for="qty">العدد</label>
                            <div class="flex justify-center items-center">
                                <button id="plus-sign" class="border border-[#6b7280] border-l-0 rounded-r-full font-bold py-[8px] px-[12px]">+</button>
                                <input type="number" name="qty" id="qty" value="1" class="w-12 text-center" min="1" max="20">
                                <button id="negative-sign" class="border border-[#6b7280] border-r-0 rounded-l-full font-bold py-[8px] px-[12px]">-</button>
                            </div>
                        </div>
                        <div class="flex-1 font-semibold">
                             أحصل على <?php echo e($meal->points); ?> نقطة عند شراء هذا المنتج
                        </div>
                    </div>
                    <button class="w-full p-4 font-semibold bg-yellow-600 border-2 border-yellow-600 text-white rounded transition hover:bg-white hover:text-yellow-600 add_to_cart" id="<?php echo e($meal->id); ?>">إضافة إلى السلة</button>
                </div>
            </div>
        </div>
    </div>

</body>

</html><?php /**PATH C:\Users\Ammar Jlies\Desktop\Graduation Project\Restaurant\resources\views/meal.blade.php ENDPATH**/ ?>