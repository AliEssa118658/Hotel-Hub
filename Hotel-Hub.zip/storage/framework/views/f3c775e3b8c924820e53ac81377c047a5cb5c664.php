<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    <title>Restaurant</title>
</head>
<body>
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="products w-full h-[83.333333%] pt-1 lg:p-8 overflow-x-hidden" dir="rtl">
        <h1 class="text-4xl text-yellow-600 text-center pb-4 lg:pb-8 shadow-sm">سلة المشتريات</h1>
        
        <table class="hidden md:table w-full table-auto text-right" dir="rtl">
            <thead class="text-white uppercase bg-yellow-600">
                <tr class="border-b">
                    <th scope="col" class="p-4 border-l">الاسم</th>
                    <th scope="col" class="p-4 border-l">السعر</th>
                    <th scope="col" class="p-4 border-l">الكمية</th>
                    <th scope="col" class="p-4 border-l">الإجمالي</th>
                    <th scope="col" class="p-4 border-l">الإجراء</th>
                </tr>
            </thead>
            <tbody>
                
            </tbody>
        </table>

        
        <div class="relative md:hidden">
            <div class="w-screen relative flex flex-col gap-4 p-4 mobile-container">
                
            </div>
            
        </div>

        <div class="mb-4 md:mb-0 flex place-order-container w-full items-center justify-center mt-8">
            <?php if(Auth::check()): ?>
            <div class="mx-2 md:mx-0 md:w-3/4 border-2 shadow-md lg:h-48 rounded-md p-4 flex flex-col gap-6 justify-center items-start">
                <div class="flex flex-col gap-2 lg:gap-0 lg:flex-row lg:items-center lg:justify-start w-full">
                    <div class="select-field flex-1 max-w-[90vw] md:w-auto md:flex-[4_4_0%]">
                        <label for="address">اختر عنوان التوصيل:</label>
                        <select name="address" id="address" dir="rtl" class="mt-2 lg:mt-0 max-w-full">
                            
                        </select>
                    </div>
                    <div class="flex-1">
                        <p>الإجمالي: <span class="total"></span></p>
                    </div>
                    <div class="flex-[2_2_0%]">
                        <label for="notes">الملاحظات:</label>
                        <input type="text" name="notes" id="notes" dir="rtl" placeholder="مع شطة، بدون مخلل ... إلخ">
                    </div>
                </div>
                <div class="flex items-center justify-center w-full">
                    <button id="place-order" class="opacity-30 text-lg rounded-md p-4 w-32 border-2 border-yellow-600 bg-yellow-600 text-white transition-all">
                        اطلب الآن
                    </button>
                </div>
            </div>
            <?php else: ?>
            <h1 class="font-bold text-center not-registered">قم <a href="/login" class="text-yellow-600 transition-all">بتسجيل الدخول</a> حتى تسطيع وضع الطلب</h1>
            <?php endif; ?>
        </div>

    </div>

    <div class="hidden mr-4 pl-1 pr-1 h-[36px] py-[5px] px-[12px] px-2 py-4 underline hover:bg-yellow-600 hover:text-white hover:scale-110 opacity-60 transition-all">

    </div>

</body>
</html><?php /**PATH C:\Users\ali\Desktop\Laravel\Restaurant\resources\views/cart.blade.php ENDPATH**/ ?>