<!DOCTYPE html>

<html>



<head>
    <title>Al Hotel</title>

    <link rel="stylesheet" href="<?php echo e(asset('node_modules/bootstrap/dist/css/bootstrap.min.css')); ?>">
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="/css/font-awesome.min.css">
    
    <link href="/css/main.css?v=<?php echo e(time()); ?>" rel="stylesheet">
    
    

    <link rel="stylesheet" href="/css/swiper-bundle.min.css" />
	<link href="/css/cookies.css?v=8" rel="stylesheet">

    
    <link rel="stylesheet" href="<?php echo e(asset('css/nouislider.min.css')); ?>">
    
    <link href="/css/aos.css" rel="stylesheet">
    <link href="/css/animate.min.css" rel="stylesheet">

    <!-- Metadata -->
    <meta charset="utf-8">
    <meta name="description" content="" />
    <meta name="keywords" content="">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="_token" content="<?php echo e(csrf_token()); ?>">



	<!-- Google tag (gtag.js) -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-BDGSP6JKJX"></script>
	<script>
	  window.dataLayer = window.dataLayer || [];
	  function gtag(){dataLayer.push(arguments);}
	  gtag('js', new Date());

	  gtag('config', 'G-BDGSP6JKJX');
	</script>

</head>

<body  onload="captchaimage()">
    <!--  Header Area Start  -->
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Page Content  -->
    <?php echo $__env->yieldContent('content'); ?>
    <!--  Footer Area Start  -->
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--  Footer Area End  -->
    <!-- Extra JS ------>
    <?php echo $__env->yieldContent('extra'); ?>

    <!-- End Extra JS -->



</body>


</html>
<?php /**PATH C:\Users\ali\Desktop\Laravel\Restaurant\resources\views/layouts/master.blade.php ENDPATH**/ ?>