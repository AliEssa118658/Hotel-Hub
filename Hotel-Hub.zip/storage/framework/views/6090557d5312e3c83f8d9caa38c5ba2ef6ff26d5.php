<?php echo e($slot); ?>

<?php /**PATH C:\Users\ali\Desktop\New folder (2)\Restaurant\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>