<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\ali\Desktop\Laravel\Hotel-Hub\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>