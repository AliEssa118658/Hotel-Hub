<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    <title>Restaurant</title>
</head>
<body class="h-screen">
    <?php echo $__env->make('layouts.kitchen-navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="min-h-fit lg:h-5/6 lg:min-h-0 flex justify-center items-start lg:items-center mb-4" dir="rtl">
        <div class="p-4 pt-2 border-2 h-5/6 w-5/6 shadow-xl flex flex-col divide-y-2 bg-white rounded overflow-y-auto main-container">
            <?php if($order && $order->count() > 0): ?>
                <div id="<?php echo e($order->id); ?>" class=" min-h-max w-full p-2 flex flex-col gap-8 divide-y-2 lg:divide-y-0 order-container text-2xl">
                    <div class="flex-[5_5_0%] h-full space-y-8 ">
                        <div class="w-full flex flex-col lg:flex-row items-center justify-center lg:justify-between gap-2 lg:gap-0">
                            <div class="flex-1 w-full lg:w-fit">
                                <p class="text-yellow-600">رقم الطلب: <span class="text-black order-id"><?php echo e($order->id); ?></span></p>
                            </div>
                            <div class="flex-1 w-full lg:w-fit">
                                <p class="text-yellow-600">حالة الطلب: <span class="text-black status"><?php echo e($order->status); ?></span></p>
                            </div>
                            <div class="flex-1 w-full lg:w-fit">
                                <p class="text-yellow-600">وقت إنشاء الطلب: <span class="text-black ordered-at"><?php echo e($order->created_at->diffForHumans()); ?></span></p>
                            </div>
                        </div>
                        <div class="flex-1 w-full lg:w-fit lg:flex lg:flex-row lg:justify-around lg:items-center">
                            <p class="text-yellow-600">الملاحظات: <span class="text-black order-notes"><?php echo e($order->notes); ?></span></p>
                        </div>
                        <div class="flex-1 w-full flex flex-col lg:flex-row items-center justify-center lg:justify-between gap-2 lg:gap-0">
                            <div class="flex-1 w-full">
                                <p class="text-yellow-600">العنوان: <span class="text-black"> <?php echo e($order->address()->withTrashed()->first()->region); ?> - <?php echo e($order->address()->withTrashed()->first()->street); ?> - الطابق: <?php echo e($order->address()->withTrashed()->first()->floorNo); ?></span></p>
                            </div>
                            <div class="flex-1 w-full">
                                <p class="text-yellow-600">رقم الهاتف: <span class="text-black"><?php echo e($order->user()->first()->phone); ?></span></p>
                            </div>
                        </div>
                        <div class="w-full flex flex-col lg:flex-row justify-center lg:justify-between gap-2 lg:gap-0">
                            <div class="flex-1 w-full lg:w-fit">
                                <p class="text-yellow-600 font-bold">الوجبات: </p>
                                <div class="flex flex-col gap-4 justify-center divide-y-2 meal-container">
                                    <?php $__currentLoopData = $order->meals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="flex items-center justify-between">
                                        <p class="lg:flex-1"><?php echo e($meal->title); ?> × <?php echo e($meal->pivot->quantity); ?></p>
                                        <div class="lg:flex-1">
                                            <input type="checkbox" name="done" class="text-yellow-600 focus:ring-yellow-600">
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="flex flex-col lg:flex-row items-end justify-between h-full w-full">
                        <button class="w-full h-14 lg:w-48 lg:h-14 text-center transition-all py-2 px-4 border-2 border-yellow-600 bg-yellow-600 text-white hover:bg-white hover:text-yellow-600 rounded-md nextOrderBtn">تم التجهيز</button>
                    </div>
                </div>
            <?php else: ?>
            <h1 class="text-center text-yellow-600 text-2xl">لا يوجد طلبات</h1>
            <?php endif; ?>
        </div>
    </div>

</body>
</html><?php /**PATH C:\Users\Ammar Jlies\Desktop\Graduation Project\Restaurant\resources\views/kitchen.blade.php ENDPATH**/ ?>