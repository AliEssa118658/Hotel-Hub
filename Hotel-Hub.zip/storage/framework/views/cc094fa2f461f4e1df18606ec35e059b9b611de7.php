<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

    <!-- Scripts -->
    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
    <title>Restaurant</title>
</head>
<body class="h-screen">
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="min-h-fit lg:h-5/6 lg:min-h-0 flex justify-center items-start lg:items-center mb-4" dir="rtl">
        <div class="border-2 h-5/6 w-5/6 shadow-xl flex flex-col lg:flex-row divide-x-2 divide-x-reverse bg-white rounded">
            <div class="h-full w-full lg:w-[70%] p-4 flex flex-col divide-y-2 gap-4 overflow-y-auto address-container">
                <?php if($addresses->count() > 0): ?>
                 <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="<?php echo e($address->id); ?>" class="w-full p-2 flex flex-col lg:flex-row items-center justify-center lg:justify-between gap-2 lg:gap-0 address">
                        <div class="flex-1 w-full lg:w-fit">
                            <p><span class="font-bold title">اسم العنوان:</span> <span class="titleValue"><?php echo e($address->title); ?></span></p>
                            <p><span class="font-bold region">المنطقة:</span> <span class="regionValue"><?php echo e($address->region); ?></span></p>
                        </div>
                        <div class="flex-1 w-full lg:w-fit">
                            <p><span class="font-bold street">الشارع:</span> <span class="streetValue"><?php echo e($address->street); ?></span></p>
                            <p><span class="font-bold floorNo">الطابق:</span> <span class="floorNoValue"><?php echo e($address->floorNo); ?></span></p>
                            <p><span class="font-bold details">تفاصيل:</span> <span class="detailsValue"><?php echo e($address->details); ?></span></p>
                        </div>
                        <div class="flex flex-col items-center justify-center space-y-2 w-full lg:w-fit">
                            <button class="w-full text-center transition-all py-2 px-4 border-2 border-yellow-600 bg-yellow-600 text-white hover:bg-white hover:text-yellow-600 hover:scale-110 rounded-md removeAddressBtn">حذف</button>
                            <button class="w-full text-center transition-all py-2 px-4 border-2 border-yellow-600 bg-yellow-600 text-white hover:bg-white hover:text-yellow-600 hover:scale-110 rounded-md editAddressBtn">تعديل</button>
                        </div>
                    </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <h1 class="text-center text-2xl text-yellow-600">لا يوجد عناوين</h1>
                <?php endif; ?>
            </div>
            <div class="h-full w-full border-t-2 lg:border-0 lg:w-[30%] p-2 px-4 pt-4">
                <h1 class="text-center text-2xl font-bold">إنشاء عنوان</h1>
                <div class="create-address flex flex-col w-full mt-8">
                    <label for="title">اسم العنوان</label>
                    <input class="rounded-md w-full mt-1 focus:ring-yellow-600 focus:ring-2 focus:border-yellow-600" type="text" name="title" id="title">
                    <label for="region">المنطقة</label>
                    <input class="rounded-md w-full mt-1 focus:ring-yellow-600 focus:ring-2 focus:border-yellow-600" type="text" name="region" id="region">
                    <label for="street">الشارع</label>
                    <input class="rounded-md w-full mt-1 focus:ring-yellow-600 focus:ring-2 focus:border-yellow-600" type="text" name="street" id="street">
                    <label for="floorNo">الطابق</label>
                    <input class="rounded-md w-full mt-1 focus:ring-yellow-600 focus:ring-2 focus:border-yellow-600" type="number" max="10" name="floorNo" id="floorNo">
                    <label for="details">تفاصيل</label>
                    <input class="rounded-md w-full mt-1 focus:ring-yellow-600 focus:ring-2 focus:border-yellow-600" type="text" name="details" id="details">
                    <button class="rounded-full py-2 bg-yellow-600 text-white mt-4 mx-4 text-center hover:scale-105 hover:bg-white hover:text-yellow-600 border-2 border-yellow-600 transition-all saveAddressBtn">حفظ</button>
                </div>
            </div>
        </div>
    </div>

</body>
</html><?php /**PATH C:\Users\Ammar Jlies\Desktop\Graduation Project\Restaurant\resources\views/addresses.blade.php ENDPATH**/ ?>