<div class="row">
    <div class="col-md-6">
        <?php if(isset($booking->room)): ?>
            <h2><?php echo e($booking->room->title); ?></h2>
            <p>Booking start time: <?php echo e(\Carbon\Carbon::parse($booking->booking_start_time)->format('Y-m-d H:i:s')); ?></p>
            <p>Booking end time: <?php echo e(\Carbon\Carbon::parse($booking->booking_end_time)->format('Y-m-d H:i:s')); ?></p>
            <p>Description: <?php echo e($booking->room->description); ?></p>
            <p class="card-text">Booking Fee: <?php echo e($booking->room->price); ?> x <?php echo e(\Carbon\Carbon::parse($booking->booking_start_time)->diffInDays(\Carbon\Carbon::parse($booking->booking_end_time))); ?> days = <?php echo e($booking->room->price * \Carbon\Carbon::parse($booking->booking_start_time)->diffInDays(\Carbon\Carbon::parse($booking->booking_end_time))); ?></p>
            <?php if($booking->paid): ?>
                <p class="card-text text-success">Paid</p>
            <?php else: ?>
                <p class="card-text text-danger">Unpaid</p>
            <?php endif; ?>
            <?php if($booking->confirmed): ?>
                <p class="card-text text-success">Confirmed</p>
            <?php else: ?>
                <p class="card-text text-danger">Unconfirmed</p>
            <?php endif; ?>
        <?php else: ?>
            <p>Room not found.</p>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\Users\ali\Desktop\Laravel\Restaurant\resources\views/bookings/show.blade.php ENDPATH**/ ?>