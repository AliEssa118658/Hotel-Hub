<div x-data="{ open: false }" class="h-1/6 z-30">

    <div x-show="open" x-transition class="fixed top-0 left-0 w-screen h-screen bg-white z-20 pt-24 pb-8" style="display: none">
    <a href="/cart" class="absolute group top-6 left-6">
        <img class="scale-100 opacity-50 group-hover:scale-125 group-hover:opacity-100 transition-all" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAACJUlEQVR4nO2Yz0sVURTHP6/iEUaJuJQg3ISQpFCJLVzZqhbiIghc2Kq/oJUREVIvonARtDF3BUaRtAlSoV1BtWkpREQ9RQzbiAbSe3HhBl8uz3Lu3LnjwHzgwJt5c77n3Llzf5wLJSUlJXuFW8A20LS2AbwFLgIVCsCGJO9ajQL2QNOxsxSMw8AzacA0BWRAGrC2wzMzwO9/9FwIWweeA8eSNqDNETLXSnvGiTcd+wEMJm3EmggM5NQDTbEPSWfFx+J8hXw44bzIRBPKVXF8SH7MSh5mbdo1w+L4jvx4L3kMJXHsFMdNYD/xOQBs2RwaQEdSgW/SiB7i0yvxv/gIvBSBS8RnTOK/8BG4KQJ3iM9diX/DR2BUBF4Tn3mJP+Ij0O2shrFZlfiJtxPYlW9dRLqIR5fE/ZmmNnkjQheIx3mJa3LwZkqErhGPCYlrcvBmXIRMnRCLpxL3chqhkyL0mXgsSdz+NEJV4Jcs56YWyJpDslU35e7BtIIf5W2cI3uGJN6nEIL3RHAxwsZuTuI9CCF43Dm5WABO291iSI4CTySO+WT7QolfD1gergCnRHvS3ms4z6WaPl0qthF/B3Rau291j7T4r2GrwEw+VbM/egR8/c+B2G57oAK8sve37O8zFJAOYF/eSRSOqi10loG6PQyuZugXnJrniXbN0y84yzsM0Kz8glNvkcj3DP2C0+pTuJ2hX3CqNpm6xyCuefiVlJSUsDf4Axp2YWimEJkBAAAAAElFTkSuQmCC">
        <span class="scale-100 opacity-50 group-hover:scale-125 transition-all group-hover:opacity-100 absolute top-[44%] left-[57%] translate-y-[-50%] translate-x-[-50%] cart">0</span>
    </a>

    <div @click="open = ! open" class="fixed right-8 top-8 cursor-pointer opacity-90">
        <svg fill="#000000" height="32px" width="32px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
        viewBox="0 0 460.775 460.775" xml:space="preserve">
            <path d="M285.08,230.397L456.218,59.27c6.076-6.077,6.076-15.911,0-21.986L423.511,4.565c-2.913-2.911-6.866-4.55-10.992-4.55
            c-4.127,0-8.08,1.639-10.993,4.55l-171.138,171.14L59.25,4.565c-2.913-2.911-6.866-4.55-10.993-4.55
            c-4.126,0-8.08,1.639-10.992,4.55L4.558,37.284c-6.077,6.075-6.077,15.909,0,21.986l171.138,171.128L4.575,401.505
            c-6.074,6.077-6.074,15.911,0,21.986l32.709,32.719c2.911,2.911,6.865,4.55,10.992,4.55c4.127,0,8.08-1.639,10.994-4.55
            l171.117-171.12l171.118,171.12c2.913,2.911,6.866,4.55,10.993,4.55c4.128,0,8.081-1.639,10.992-4.55l32.709-32.719
            c6.074-6.075,6.074-15.909,0-21.986L285.08,230.397z"/>
        </svg>
    </div>

    <div class="h-full w-full flex flex-col items-center justify-center space-y-8">

        <a href='/#end' @click="open = ! open" class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
            من نحن ؟
        </a>
        <a href='/#main' @click="open = ! open" class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
            أفضل الفنادق
        </a>
        <a href='/#main' @click="open = ! open" class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
            المحافظات
        </a>

        <div class="flex items-center mx-auto" dir="rtl">
            <div class="p-2 rounded-r-full rounded-l-none bg-gray-100 focus:outline-none cursor-pointer" id="search">
                <svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 24 24" width="24px" height="24px"><path d="M 9 2 C 5.1458514 2 2 5.1458514 2 9 C 2 12.854149 5.1458514 16 9 16 C 10.747998 16 12.345009 15.348024 13.574219 14.28125 L 14 14.707031 L 14 16 L 20 22 L 22 20 L 16 14 L 14.707031 14 L 14.28125 13.574219 C 15.348024 12.345009 16 10.747998 16 9 C 16 5.1458514 12.854149 2 9 2 z M 9 4 C 11.773268 4 14 6.2267316 14 9 C 14 11.773268 11.773268 14 9 14 C 6.2267316 14 4 11.773268 4 9 C 4 6.2267316 6.2267316 4 9 4 z"/></svg>
            </div>
            <input id="searchbar" class="rounded-r-none rounded-l-full bg-gray-100 focus:outline-none p-2" placeholder="بحث">
        </div>

        <?php if(Auth::check()): ?>
            <div class="select-none text-2xl text-yellow-600 transition my-auto text-center">
                <div class="block py-2">
                    <?php echo e(Auth::user()->name); ?>

                </div>
                <div class="text-yellow-600 my-auto text-center text-2xl flex-1 py-2 balance">
                    <p>الرصيد: <?php echo e(Auth::user()->balance); ?></p>
                </div>
                <a href="/addresses" class="block py-2 px-6 transition-all z-30">العناوين</a>
                <a href="/orders" class="block py-2 px-6 transition-all z-30">طلباتي</a>
                <a href="/points" class="block py-2 px-6 transition-all z-30">النقاط</a>
                <a href="/logout" class="block py-2 px-6 transition-all z-30">تسجيل الخروج</a>
            </div>
        <?php else: ?>
            <a href="/login" class="scale-100 hover:scale-110 p-2 rounded-full bg-yellow-600 text-white hover:bg-white hover:text-yellow-600 border-2 border-yellow-600 transition-all flex items-center">
                التسجيل / تسجيل الدخول
            </a>
        <?php endif; ?>

    </div>
    </div>

    <nav class="z-30 w-full py-4 top-0 h-1/6 bg-white font-semibold backdrop-filter backdrop-blur-lg bg-opacity-30">

    <div class="flex px-16 lg:px-8 items-center justify-between lg:justify-between">

        <div class="hidden lg:flex justify-evenly space-x-8">
            <?php if(Auth::check()): ?>
            <div class="dropdown z-30 relative flex items-center group transition cursor-pointer select-none text-2xl text-yellow-600 my-auto">
                <div class="">
                    <?php echo e(Auth::user()->name); ?>

                    <span class="block max-w-0 group-hover:max-w-full bg-yellow-600 h-0.5 transition-all"></span>
                </div>

                <svg fill="#000000" class="ml-2 mt-[2px] transition-all" height="12px" width="12px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                viewBox="0 0 330 330" xml:space="preserve">
                <path id="XMLID_225_" d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393
                c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393
                s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"/>
                </svg>

                <div class="dropdown-menu z-30 absolute bottom-[-210px] left-[50px] bg-white text-yellow-600 text-md border rounded-md shadow-md transition-all scale-0 origin-top whitespace-nowrap" dir="rtl">
                    <a href="/addresses" class="dropdown-menu-item block py-2 px-6 transition-all hover:bg-yellow-600 hover:text-white rounded-md z-30">العناوين</a>
                    <a href="/orders" class="dropdown-menu-item block py-2 px-6 transition-all hover:bg-yellow-600 hover:text-white rounded-md z-30">طلباتي</a>
                    <a href="/points" class="dropdown-menu-item block py-2 px-6 transition-all hover:bg-yellow-600 hover:text-white rounded-md z-30">النقاط</a>
                    <a href="/logout" class="dropdown-menu-item block py-2 px-6 transition-all hover:bg-yellow-600 hover:text-white rounded-md z-30">تسجيل الخروج</a>
                </div>
            </div>
            <div class="text-yellow-600 my-auto text-center text-2xl flex-1 balance">
                <p>الرصيد: <?php echo e(Auth::user()->balance); ?></p>
            </div>
            <?php else: ?>
                <a href="/login" class="scale-100 hover:scale-110 p-2 rounded-full bg-yellow-600 text-white hover:bg-white hover:text-yellow-600 border-2 border-yellow-600 transition-all flex items-center">
                    التسجيل / تسجيل الدخول
                </a>
            <?php endif; ?>

            <a href="/cart" class="relative group">
                <img class="scale-100 opacity-50 group-hover:scale-125 group-hover:opacity-100 transition-all" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAACXBIWXMAAAsTAAALEwEAmpwYAAACJUlEQVR4nO2Yz0sVURTHP6/iEUaJuJQg3ISQpFCJLVzZqhbiIghc2Kq/oJUREVIvonARtDF3BUaRtAlSoV1BtWkpREQ9RQzbiAbSe3HhBl8uz3Lu3LnjwHzgwJt5c77n3Llzf5wLJSUlJXuFW8A20LS2AbwFLgIVCsCGJO9ajQL2QNOxsxSMw8AzacA0BWRAGrC2wzMzwO9/9FwIWweeA8eSNqDNETLXSnvGiTcd+wEMJm3EmggM5NQDTbEPSWfFx+J8hXw44bzIRBPKVXF8SH7MSh5mbdo1w+L4jvx4L3kMJXHsFMdNYD/xOQBs2RwaQEdSgW/SiB7i0yvxv/gIvBSBS8RnTOK/8BG4KQJ3iM9diX/DR2BUBF4Tn3mJP+Ij0O2shrFZlfiJtxPYlW9dRLqIR5fE/ZmmNnkjQheIx3mJa3LwZkqErhGPCYlrcvBmXIRMnRCLpxL3chqhkyL0mXgsSdz+NEJV4Jcs56YWyJpDslU35e7BtIIf5W2cI3uGJN6nEIL3RHAxwsZuTuI9CCF43Dm5WABO291iSI4CTySO+WT7QolfD1gergCnRHvS3ms4z6WaPl0qthF/B3Rau291j7T4r2GrwEw+VbM/egR8/c+B2G57oAK8sve37O8zFJAOYF/eSRSOqi10loG6PQyuZugXnJrniXbN0y84yzsM0Kz8glNvkcj3DP2C0+pTuJ2hX3CqNpm6xyCuefiVlJSUsDf4Axp2YWimEJkBAAAAAElFTkSuQmCC">
                <span class="scale-100 opacity-50 group-hover:scale-125 transition-all group-hover:opacity-100 absolute top-[44%] left-[57%] translate-y-[-50%] translate-x-[-50%] cart">0</span>
            </a>

            <div class="flex items-center" dir="rtl">
                <div id="search" class="p-2 rounded-r-full rounded-l-none bg-gray-100 focus:outline-none cursor-pointer">
                    <svg xmlns="http://www.w3.org/2000/svg"  viewBox="0 0 24 24" width="24px" height="24px" class=""><path d="M 9 2 C 5.1458514 2 2 5.1458514 2 9 C 2 12.854149 5.1458514 16 9 16 C 10.747998 16 12.345009 15.348024 13.574219 14.28125 L 14 14.707031 L 14 16 L 20 22 L 22 20 L 16 14 L 14.707031 14 L 14.28125 13.574219 C 15.348024 12.345009 16 10.747998 16 9 C 16 5.1458514 12.854149 2 9 2 z M 9 4 C 11.773268 4 14 6.2267316 14 9 C 14 11.773268 11.773268 14 9 14 C 6.2267316 14 4 11.773268 4 9 C 4 6.2267316 6.2267316 4 9 4 z"/></svg>
                </div>
                <input id="searchbar" class="rounded-r-none rounded-l-full bg-gray-100 focus:outline-none p-2" placeholder="بحث">
            </div>

        </div>

        <div @click="open = ! open" class="relative lg:hidden scale-125">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAAANUlEQVR4nO3VsQkAMAwDwd9/rGiwZIIUAYs0f6DaIBAGSQUBdjn5dXg1GpOunJM0Jn4nSTw4Ff6YkoE1i0QAAAAASUVORK5CYII=">
        </div>

        <div class="hidden lg:flex space-x-10">
            <a href='/#end' class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
                من نحن ؟
            </a>
            <a href='/#main' class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
                أفضل الفنادق
            </a>
            <a href='/#main' class="hover:text-yellow-600 hover:scale-110 transition-all text-2xl">
                المحافظات
            </a>
        </div>

        <div class="">
            <a href="/">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.application-logo-home','data' => ['class' => 'w-24 h-24 fill-current text-gray-500']]); ?>
<?php $component->withName('application-logo-home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-24 h-24 fill-current text-gray-500']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </a>
        </div>

    </div>
    </nav>

</div>
<?php /**PATH C:\Users\ali\Desktop\Laravel\Restaurant\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>