<div x-data="{ open: false }" class="h-1/6 z-30">

    <div x-show="open" x-transition class="fixed top-0 left-0 w-screen h-screen bg-white z-20 pt-24 pb-8" style="display: none">

    <div @click="open = ! open" class="fixed right-8 top-8 cursor-pointer opacity-90">
        <svg fill="#000000" height="32px" width="32px" version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
        viewBox="0 0 460.775 460.775" xml:space="preserve">
            <path d="M285.08,230.397L456.218,59.27c6.076-6.077,6.076-15.911,0-21.986L423.511,4.565c-2.913-2.911-6.866-4.55-10.992-4.55
            c-4.127,0-8.08,1.639-10.993,4.55l-171.138,171.14L59.25,4.565c-2.913-2.911-6.866-4.55-10.993-4.55
            c-4.126,0-8.08,1.639-10.992,4.55L4.558,37.284c-6.077,6.075-6.077,15.909,0,21.986l171.138,171.128L4.575,401.505
            c-6.074,6.077-6.074,15.911,0,21.986l32.709,32.719c2.911,2.911,6.865,4.55,10.992,4.55c4.127,0,8.08-1.639,10.994-4.55
            l171.117-171.12l171.118,171.12c2.913,2.911,6.866,4.55,10.993,4.55c4.128,0,8.081-1.639,10.992-4.55l32.709-32.719
            c6.074-6.075,6.074-15.909,0-21.986L285.08,230.397z"/>
        </svg>
    </div>

    <div class="h-full w-full flex flex-col items-center justify-center space-y-8">

        <?php if(Auth::check()): ?>
            <div class="select-none text-2xl text-yellow-600 transition my-auto text-center">
                <div class="block py-2">
                    <?php echo e(Auth::user()->name); ?>

                </div>
                <a href="/logout" class="block py-2 px-6 transition-all z-30">تسجيل الخروج</a>
            </div>
        <?php else: ?>
            <a href="/login" class="scale-100 hover:scale-110 p-2 rounded-full bg-yellow-600 text-white hover:bg-white hover:text-yellow-600 border-2 border-yellow-600 transition-all flex items-center">
                التسجيل / تسجيل الدخول
            </a>
        <?php endif; ?>

    </div>
    </div>

    <nav class="z-30 w-full top-0 h-1/6 bg-white font-semibold backdrop-filter backdrop-blur-lg bg-opacity-30">
            
    <div class="flex px-16 lg:px-8 items-center justify-between lg:justify-between border-b-2 shadow-md">

        <div class="hidden lg:flex justify-evenly space-x-8">
            <?php if(Auth::check()): ?>
            <div class="dropdown z-30 relative flex items-center group transition cursor-pointer select-none text-2xl text-yellow-600 my-auto">
                <div class="">
                    <?php echo e(Auth::user()->name); ?>

                    <span class="block max-w-0 group-hover:max-w-full bg-yellow-600 h-0.5 transition-all"></span>
                </div>

                <svg fill="#000000" class="ml-2 mt-[2px] transition-all" height="12px" width="12px" version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" 
                viewBox="0 0 330 330" xml:space="preserve">
                <path id="XMLID_225_" d="M325.607,79.393c-5.857-5.857-15.355-5.858-21.213,0.001l-139.39,139.393L25.607,79.393
                c-5.857-5.857-15.355-5.858-21.213,0.001c-5.858,5.858-5.858,15.355,0,21.213l150.004,150c2.813,2.813,6.628,4.393,10.606,4.393
                s7.794-1.581,10.606-4.394l149.996-150C331.465,94.749,331.465,85.251,325.607,79.393z"/>
                </svg>

                <div class="dropdown-menu z-30 absolute bottom-[-60px] left-[50px] bg-white text-yellow-600 text-md border rounded-md shadow-md transition-all scale-0 origin-top whitespace-nowrap" dir="rtl"> 
                    <a href="/logout" class="dropdown-menu-item block py-2 px-6 transition-all hover:bg-yellow-600 hover:text-white rounded-md z-30">تسجيل الخروج</a>
                </div>
            </div>
            <?php else: ?>
                <a href="/login" class="scale-100 hover:scale-110 p-2 rounded-full bg-yellow-600 text-white hover:bg-white hover:text-yellow-600 border-2 border-yellow-600 transition-all flex items-center">
                    التسجيل / تسجيل الدخول
                </a>
            <?php endif; ?>

        </div>

        <div @click="open = ! open" class="relative lg:hidden scale-125">
            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAAANUlEQVR4nO3VsQkAMAwDwd9/rGiwZIIUAYs0f6DaIBAGSQUBdjn5dXg1GpOunJM0Jn4nSTw4Ff6YkoE1i0QAAAAASUVORK5CYII=">
        </div>

        <div class="">
            <div href="/">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.application-logo-home','data' => ['class' => 'w-24 h-24 fill-current text-gray-500']]); ?>
<?php $component->withName('application-logo-home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-24 h-24 fill-current text-gray-500']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
        </div>

    </div>
    </nav>

</div><?php /**PATH C:\Users\Ammar Jlies\Desktop\Graduation Project\Restaurant\resources\views/layouts/kitchen-navbar.blade.php ENDPATH**/ ?>