<?php echo e($slot); ?>

<?php /**PATH C:\Users\ali\Desktop\Laravel\Hotel-Hub\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>